import { withRouter } from "next/router"

export default function withHoc(Component: any) {
    function withWarp(props: any) {
        console.log('%c⧭', 'color: #807160', "HOC MOUND");
        return <Component {...props} hoc={"hoc"} />
    }
    // return withRouter(withWarp)
    return withWarp
}
