export default function sampleHoc(Component: any) {
    function withWarp(props: any) {
        return <Component {...props} hoc={"hoc"} />
    }
    return withWarp
}