import { useState } from "react";

export default function useCount(props: any) {
    const [count, setCount] = useState(props || 0)
    const increment = () => {
        setCount(count + 1)
    }

    const decrement = () => {
        setCount(count - 1)
    }

    return [
        count,
        increment,
        decrement
    ]
}