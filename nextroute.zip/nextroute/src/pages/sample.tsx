import SampleComponet from "@/component/SampleComponent"
import { useRouter } from "next/router"
import { useCallback, useContext, useEffect, useMemo, useState } from "react"
import { ThemeContext } from "./_app"

function Sample(props: any) {
    console.log('%c⧭', 'color: #e57373', props);
    const route = useRouter()
    const data = useContext(ThemeContext)

    const [sampleState, setSampleState] = useState<any>("")

    useEffect(() => {
        handleState()
    }, [route.query])

    const handleState = () => {
        setSampleState({
            UserSettings: [
                "DELETE_USER",
                "APP_ADMIN"
            ]
        })
        console.log('%c⧭', 'color: #aa00ff', sampleState);
    }

    useEffect(() => {


        console.log('%c⧭', 'color: #e50000', sampleState);
    }, [sampleState])

    // let Json = 
    // {
    //     UserSettings: [
    //         "DELETE_USER",
    //         "APP_ADMIN"
    //     ]
    // }
    // let str = JSON.stringify(Json)
    // let parse = JSON.parse(str)
    // console.log('%c⧭', 'color: #00e600', Json,typeof str, parse);

    return (
        <>
            {/* This is sample page */}
            <button
                onClick={() => route.push({ pathname: "/sample", query: { data: "SampleId 1" } })}>
                HI This is gove
            </button>

            <button
                onClick={() => route.push({ pathname: "/sample", query: { data: "SampleId 2" } })}>
                HI This is gove 2
            </button>
            <SampleComponet porperties={"GOVE"} />
        </>
    )
}
export default Sample

export const getStaticProps = () => {
    return { props: { name: "aswin" }, revalidate: 1 }
}

