import React, { useState, useEffect } from 'react';
import axios from "axios"
import { useRouter } from 'next/router';
function InfiniteScroll({ loadData }: any) {
  const [data, setData] = useState<any>([]);
  const [page, setPage] = useState(1);
  const route = useRouter()

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    axios.get('https://api.publicapis.org/entries').then((newData: any) => {
      setData((prevData: any) =>
        [
          ...prevData,
          ...newData.data.entries.map((data: any) => data.API)
        ]);
      setIsLoading(false);
    });
  }, [page]);

  function handleScroll() {
    const scrollTop = document.documentElement.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight;
    const clientHeight = document.documentElement.clientHeight;

    console.log('%c⧭', 'color: #f200e2', scrollTop, scrollHeight, clientHeight);
    if (scrollTop + clientHeight >= scrollHeight && !isLoading) {
      console.log('%c⧭', 'color: #731d1d',);
      setPage((prevPage) => prevPage + 1);
    }
  }

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div>
      {data.map((item: string, index: number) => (
        <>
          <Card key={index} data={item} index={index} />
        </>
      ))}
      {isLoading && <div>Loading...</div>}
    </div>
  );
}

function Card({ data, index }: any) {
  return (
    <div>
      <h2>{index}.{data}</h2>
    </div>
  );
}

export default InfiniteScroll;
