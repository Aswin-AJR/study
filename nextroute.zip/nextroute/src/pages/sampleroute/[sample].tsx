import sampleHoc from "@/hoc/sample2.hoc"
import { useRouter } from "next/router"

function Sample(props: any) {
    console.log('%c⧭', 'color: #731d6d', props);
    const router = useRouter()
    console.log(">>>>>>>>>>..", router.query)
    return <>Sample
        <button onClick={() => router.push({ pathname: "/sample", query: "hi" })} > push</button ></>
}
export default sampleHoc(Sample)