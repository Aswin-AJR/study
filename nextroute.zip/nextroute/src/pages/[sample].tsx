import { useRouter } from "next/router";
import withHoc from "../hoc/sample.hoc"
import useCount from "@/hooks/samplehooks";
import { useEffect } from "react";
function Sample() {
    const route = useRouter()
    const [count, increment, decrement] = useCount(0)
    console.log('%c⧭', 'color: #007300', "COMPONENT MOUND", route?.query?.sample);
    useEffect(() => {

        console.log('%c⧭', 'color: #006dcc', count);
    }, [count])
    return (
        <>HI
            <button onClick={increment} >increment</button>
            <button onClick={decrement} >decrement</button>
            <span>{count}</span>

        </>
    )
}

export default withHoc(Sample)