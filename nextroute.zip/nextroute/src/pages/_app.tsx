import '@/styles/globals.css'
import type { AppProps } from 'next/app'
import React from 'react';
export const ThemeContext = React.createContext({});

export default function App({ Component, pageProps }: AppProps) {
  // return <Component {...pageProps} />
  return (
    <>
      <ThemeContext.Provider value={"dark"}>
        <Component {...pageProps} />
      </ThemeContext.Provider>
    </>
  )
}
