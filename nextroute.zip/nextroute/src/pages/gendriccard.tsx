import React from 'react';
import { Card, CardContent, CardMedia, Typography } from '@mui/material';

const data: any = [
    {
        title: 'My Card Title',
        subtitle: 'My Card Subtitle',
        text: 'Some text to display in the card',
        image: 'https://example.com/my-image.jpg',
    
    },{
        title: 'My Card Title',
        subtitle: 'My Card Subtitle',
        text: 'Some text to display in the card',
        image: 'https://example.com/my-image.jpg',
    
    },{
        title: 'My Card Title',
        subtitle: 'My Card Subtitle',
        text: 'Some text to display in the card',
        image: 'https://example.com/my-image.jpg',
    
    },{
        title: 'My Card Title',
        subtitle: 'My Card Subtitle',
        text: 'Some text to display in the card',
        image: 'https://example.com/my-image.jpg',
    
    }
]

const config: any = {
    title: 'title',
    subtitle: 'subtitle',
    text: 'text',
    image: 'image',

};


const GenericCard = () => {
    return (
        data.map((data: any, index: any) =>
            <Card key={index}>
                {config.image && (
                    <CardMedia
                        component="img"
                        height="200"
                        image={data[config.image]}
                        alt={config.image}
                    />
                )}
                <CardContent>
                    {config.title && (
                        <Typography variant="h5" component="div">
                            {data[config.title]}
                        </Typography>
                    )}
                    {config.subtitle && (
                        <Typography variant="subtitle1" component="div">
                            {data[config.subtitle]}
                        </Typography>
                    )}
                    {config.text && (
                        <Typography variant="body1" component="div">
                            {data[config.text]}
                        </Typography>
                    )}
                </CardContent>
            </Card>)
    );
};

export default GenericCard