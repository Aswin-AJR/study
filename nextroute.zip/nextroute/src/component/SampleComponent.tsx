function SampleComponet(props:any) {
console.log('%c⧭', 'color: #733d00',props );

    return(
        <> HI </>
    )

}
export default SampleComponet