import { useEffect, useState } from "react"

function Topbar(props: any) {
    const [render, SetRender] = useState<any>(null)
    useEffect(() => {
        const getRemotePage = async () => {
            const AppList: any = {
                App1: (await import("App1/PAGES" as any) as any).default
            }
            SetRender(AppList)
        }
        getRemotePage()
    }, [])


    const handleRenderDashBoard = (component: any) => {
        let Remote: any = null;
        if (render?.App1 && render?.App1?.Footer) {
            Remote = render?.App1?.Footer;
            return (
                <Remote key={"App1" + "_" + "Footer"} >
                    {component}
                </Remote >
            )
        } else {
            return null
        }
    }

    return (
        <>
            {render && handleRenderDashBoard(props)}
        </>
    )
}
export { Topbar }