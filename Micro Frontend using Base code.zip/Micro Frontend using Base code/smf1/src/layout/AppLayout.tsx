import React, { useContext, useEffect, useState } from 'react'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar';
import { Footer } from './Footer';
import styled, { useTheme } from 'styled-components'
import { AppLayoutConfig } from '../config//AppLayoutConfig';
import _ from 'lodash'
import { TopbarConfig } from '../config/TopbarConfig';
import { SidebarConfig } from '../config/SidebarConfig';
import { FooterConfig } from '../config/FooterConfig';
import { AppConfig } from '../config/AppConfig';


/**
 * This interface defines properties of theme
 */

/**
 * Initializing the objects for imported classes
 */

let appConfig = new AppConfig()
let layoutConfig = new AppLayoutConfig()
let topbarConfig = new TopbarConfig()
let sidebarConfig = new SidebarConfig()
let footerConfig = new FooterConfig()

const LayoutContainer = styled.div`
    display: flex;
    height: 100vh;
`

const MainContainer = styled.div`
    display       : flex;
    flex-direction: column;
    height        : 100vh !important;
`

const MainDynamicComponent = styled.div`
    flex-grow: 1;
    background: $AppBackgroundColor;
    font-size: ${(props: any) => props?.fontsize + '!important' || '14px !important'};
`

function AppLayout(props: any) {

    const [appLayoutConfig, setAppLayoutConfig] = useState<any>(layoutConfig)
    const userSettings = {
        "AuthKey": "dinesh-auth-key",
        "User": {
            "UserKey": "dinessh-user-key",
            "UserName": "Dinesh",
            "UserEmail": "dinesh@alitasys.com",
            "UserType": "CUSTOMER",
            "UserRole": "SUPER-ADMIN"
        },
        "Merchant": {
            "MerchantKey": "alita-merchant-key",
            "MerchantName": "Alita",
            "MerchantLogoURL": "https://assets.alitasys.com/logo/merchant/{merchant-key}"
        },
        "Tenant": [
            {
                "TenantKey": "penske-tenant-key",
                "TenantName": "Penske",
                "TenantLogoURL": "https://assets.alitasys.com/logo/tenant/{tenant-key}"
            },
            {
                "TenantKey": "ryder-tenant-key",
                "TenantName": "Ryder",
                "TenantLogoURL": "https://assets.alitasys.com/logo/tenant/{tenant-key}"
            }
        ],
        "InstanceSettings": {
            "EnvironmentName": "DEV"
        },
        "ThemeSetting": {
            "ThemeName": "Default Theme",
            "FontFamily": "calibri",
            "FontSize": "14px",
            "AppPrimaryColor": "#1f1044",
            "TopbarBackgroundColor": "#1f1044",
            "TopbarFontColor": "White",
            "SidebarBackgroundColor": "whitesmoke",
            "SidebarFontColor": "Black",
            "BodyBackgroundColor": "White",
            "BodyFontColor": "Black",
            "FooterBackgroundColor": "Whitesmoke",
            "FooterFontColor": "Black"
        },
        "SidebarSettings": {
            "Dashboard": {
                "MenuDisplayName": "Boards",
                "IsMenuEnabled": true,
                "SubMenus": null
            },
            "User": {
                "MenuDisplayName": "Users",
                "IsMenuEnabled": true,
                "SubMenus": {
                    "Create User": {
                        "MenuDisplayName": "Create User",
                        "IsMenuEnabled": true
                    },
                    "Delete User": {
                        "MenuDisplayName": "Delete User",
                        "IsMenuEnabled": true
                    }
                }
            },
            "Settings": {
                "MenuDisplayName": "Settings",
                "IsMenuEnabled": true,
                "SubMenus": null
            }
        },
        "LocaleSettings": {
            "DisplayDateFormat": "MM/DD/YYYY hh:mm:ss",
            "DisplayTimeZone": "America/New_York",
            "StoredDateFormat": "yyyy-MM-DDTHH:mm:ss",
            "StoredTimeZone": "America/New_York",
            "DateFieldFormat": "m/d/Y",
            "TimeFieldFormat": "H:i:ss K",
            "StoredCurrencyFormat": "USD",
            "DisplayCurrencyFormat": "USD",
            "DisplayLanguage": "en"
        }
    }
    const theme = useTheme()

    useEffect(() => {
        let appLayoutConfigClone: any = { ...appLayoutConfig }
        // appLayoutConfigClone.IS_SIDEBAR_VISIBLE = true
        setAppLayoutConfig(appLayoutConfigClone)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // useEffect(() => {
    //     // logMessage("User navigated to " + window.location.href + " on " + new Date())
    //     // eslint-disable-next-line react-hooks/exhaustive-deps
    // }, [window.location.href]);

    return (
        <>
            <LayoutContainer data-testid='base_web_layout_applayout_container'>
                {/* <Sidebar
                    configs={{
                        sideBarConfig: {
                            sidebarMenuConfig: sidebarConfig.GET_SIDEBAR_MENU_CONFIG(!_.isEmpty(userSettings) ? userSettings?.SidebarSettings : null),
                            sidebarAppLogoWidth: sidebarConfig.SIDEBAR_CONFIG.SIDEBAR_APP_LOGO_WIDTH,
                            sidebarAppLogoHeight: sidebarConfig.SIDEBAR_CONFIG.SIDEBAR_APP_LOGO_HEIGHT,
                        },
                        appConfig: {
                            appName: appConfig.APP_CONFIG.APP_NAME,
                            appLogo: appConfig.APP_CONFIG.APP_LOGO,
                            appTheme: theme
                        }
                    }}
                    data={{}}
                    callbacks={null}
                /> */}
                <MainContainer data-testid="base_web_layout_applayout_maincontainer" className="main_container w-100">
                    {/* <Topbar
                        configs={{
                            sideBarConfig: {
                                isSidebarVisible: appLayoutConfig?.APP_LAYOUT_CONFIG?.IS_SIDEBAR_VISIBLE
                            },
                            appConfig: {
                                appName: appConfig.APP_CONFIG.APP_NAME,
                                appLogo: appConfig.APP_CONFIG.APP_LOGO,
                                appTheme: theme
                            },
                            topbarConfig: {
                                topbarMenuConfig: topbarConfig.GET_TOPBAR_MENU_CONFIG(),
                                topbarAppLogoWidth: topbarConfig.TOPBAR_CONFIG.TOPBAR_APP_LOGO_WIDTH,
                                topbarAppLogoHeight: topbarConfig.TOPBAR_CONFIG.TOPBAR_APP_LOGO_HEIGHT,
                            }
                        }}
                        data={{
                            tenantList: userSettings?.Tenant,
                            merchantInfo: userSettings?.Merchant,
                            instanceInfo: userSettings?.InstanceSettings,
                            userInfo: userSettings?.User
                        }}
                        callbacks={null}
                    /> */}

                    {/** Dynamic component will be routed here */}
                    <MainDynamicComponent fontsize={theme?.FontSize} data-testid="base_web_layout_applayout_maindynamiccontainer" className="py-3 px-3 sm:px-6 lg:px-8 main_dynamic_component">
                        {props.children}
                    </MainDynamicComponent>

                    {/* <Footer
                        configs={{
                            footerConfig: {
                                footerText: footerConfig.FOOTER_CONFIG.FOOTER_TEXT
                            },
                            appConfig: {
                                appTheme: theme
                            },
                        }}
                        data={null}
                        callbacks={null}
                    /> */}
                </MainContainer>
            </LayoutContainer>
        </>
    )
}

export { AppLayout }