import Head from 'next/head'
import Image from 'next/image'
import { Inter } from '@next/font/google'
import styles from '@/styles/Home.module.css'
import { useEffect, useState } from 'react'


export default function Home() {
  const [render, SetRender] = useState<any>(null)
  useEffect(() => {
    const getRemotePage = async () => {
      const AppList: any = {
        App1: (await import("App1/PAGES" as any) as any).default
      }
      SetRender(AppList)
    }
    getRemotePage()
  }, [])


  const handleRenderDashBoard = () => {
    let Remote: any = null;
    console.log('%c⧭', 'color: #ff0000',render );
    if (render?.App1 && render?.App1?.Home) {
      Remote = render?.App1?.Home;
      return (
        <Remote key={"App1" + "_" + "Index"} />
        //   {/* {component} */}
        // {/* </Remote> */}
      )
    } else {
      return null
    }
  }
  return (
    <>
      {render && handleRenderDashBoard()}
    </>
  )
}
