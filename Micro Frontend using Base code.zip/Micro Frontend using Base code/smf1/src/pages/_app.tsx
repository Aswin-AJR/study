import '@/styles/globals.css'
import type { AppProps } from 'next/app'
import '@module-federation/nextjs-mf/src/include-defaults';
import { AppLayout } from '@/layout/AppLayout';

export default function App({ Component, pageProps }: AppProps) {
  return (
    <AppLayout>
      <Component {...pageProps} />
    </AppLayout>
  )
}
