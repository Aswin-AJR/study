/**
@CreatedBy        : Karthick
@CreatedTime      : Dec 29 2022
@ModifiedBy       : Karthick
@ModifiedTime     : Dec 29 2022
@Description      : This file contains config for app file
**/

class AppConfig {
    featureConfig = {
        "base.web.feature.users": {
            "base.web.feature.users.createuser": {
                "featureID": 1.1,
                "isFeatureActive": true,
                "featureURL": "/users/createuser"
            },
            "base.web.feature.users.listusers": {
                "featureID": 1.2,
                "isFeatureActive": true,
                "featureURL": null
            },
            "base.web.feature.users.searchusers": {
                "featureID": 1.3,
                "isFeatureActive": true,
                "featureURL": null
            }
        }
    }

    PUBLIC_ROUTES_WITHOUT_PRIVATE_APP_LAYOUT: (string)[] = ['/signin']
    USER_RESTRICTED_ROUTES: (string | null)[] = []

    //Application Theme Config
    APP_CONFIG = {
        APP_LOGO: "/favicon.ico",
        APP_NAME: "Document Management"
    }

    APP_THEME_CONFIG = {
        SIDEBAR_BACKGROUND_COLOR: 'whitesmoke',
        TOPBAR_BACKGROUND_COLOR: '#1f1044'
    }

    constructor() {
        const userRestrictedRoutes = Object.values(this.featureConfig)
            .map(group => Object.values(group))
            .flat()
            .filter(feature => !feature.isFeatureActive && feature.featureURL)
            .map(feature => feature.featureURL)
            .filter(url => url !== null);
        this.USER_RESTRICTED_ROUTES = userRestrictedRoutes
    }
}

export { AppConfig }
