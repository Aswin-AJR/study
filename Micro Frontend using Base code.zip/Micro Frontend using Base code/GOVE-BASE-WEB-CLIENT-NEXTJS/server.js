/**
* CreatedBy        : Dinesh
* CreatedTime      : August 30 2022
* Description      : This file used to run the next js app in HTTPS
**/


// Importing all the node modules
const fs = require("fs");
const next = require("next");
const https = require("https");
const { parse } = require("url");
const config = require("./config");


// Initializing the next application
const Config = new config();
const dev = process.env.NODE_ENV !== "production";
const dmsWebClient = next({ dev });
const handle = dmsWebClient.getRequestHandler();

dmsWebClient.prepare().then(() => {
  if (Config.WEB_CLIENT_SECURITY_ENABLED === "true") {
    const securityConfig = {
      key: fs.readFileSync(Config.WEB_CLIENT_SECURITY_KEY_FILE_PATH),
      cert: fs.readFileSync(Config.WEB_CLIENT_SECURITY_CERT_FILE_PATH),
    };
    https
      .createServer(securityConfig, (request, response) => {
        try {
          const parsedURL = parse(request.url, true);
          handle(request, response, parsedURL);
        } catch (error) {
          console.error("Error occurred handling", request.url, error);
          response.statusCode = 500;
          response.end("Internal server error");
        }
      })
      .listen(Config.WEB_CLIENT_PORT);
  }
});
