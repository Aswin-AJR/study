# BASE-WEB-CLIENT

![Maintainer](https://img.shields.io/badge/Maintainer-Karthick/Dinesh-blue)
> ## Description
       This project contains base code for WEB-CLIENT. Change some of the configurations and this base code will be available for your project. Happy Coding
-----------------------------
> ## How to install & run BASE-WEB-CLIENT

```shell
## To install dependencies
npm install
```
```shell
## To run BASE-WEB-CLIENT in local environment (Runs in http)
npm run local
```
```shell
## To run BASE-WEB-CLIENT in local environment (Runs in https)
npm run start
```
-------------------------------
> ## How to build BASE-WEB-CLIENT
```shell
## To build the code
npm run build
```
-------------------------------
> ## Steps to use SDK functions
> ##### NOTE:- Currently there is no Private NPM Registry. So, we need to manually install the sdk. So Please follow the 
       below steps to use the SDK in WebClient. 

       step 1 : run npm i
       step 2 : Build SDK (To Build refer README.md file in SDK)
       Step 3 : Copy basesdk folder which is created after build
       step 4 : Paste the basesdk folder in nodemodules
       step 5 : Uncomment basesdk import statement and basesdk initialisation in main.tsx (component/main.tsx)
-----------------------------
> ## Why Use babel
       Babel is a free and open-source JavaScript transcompiler that is mainly used to convert ECMAScript 2015+ code into backwards-compatible JavaScript code that can be run by older JavaScript engines

-----------------------------
> ## Links
- [Async-Await inside react useEffect hook](https://ultimatecourses.com/blog/using-async-await-inside-react-use-effect-hook)
- [Prerendering](https://www.computerhope.com/jargon/p/prerendering.htm)
-----------------------------
> ## Docker Links
- https://stackoverflow.com/questions/45638302/error-trying-to-install-docker-in-windows-server-2016-with-install-module/64654070#64654070
- https://www.appsloveworld.com/docker/100/149/no-matching-manifest-for-windows-amd64-10-0-17134-in-the-manifest-list-entries

