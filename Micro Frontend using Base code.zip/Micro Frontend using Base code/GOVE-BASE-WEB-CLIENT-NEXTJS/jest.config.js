/**
@CreatedBy        : Dinesh
@CreatedTime      : Nov 30 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Nov 30 2022
@Description      : This file contain all the unit test framework jest configuration
**/

const nextJest = require("next/jest");
const createJestConfig = nextJest({
  dir: "./",
});
const customJestConfig = {
  moduleDirectories: ["node_modules", "<rootDir>/"],
  testEnvironment: "jest-environment-jsdom",

  // File name pattern to detect as a test file
  // testRegex: '\\Test\\.js$',

  // The directory where Jest should output its coverage files
  coverageDirectory: "test/coverage",
  verbose: false,
  setupFilesAfterEnv: ['./test/main.js'],
  reporters: [
    "default",
    [
      "./node_modules/jest-html-reporter",
      {
        pageTitle: `Web-Client-Test-Report`,
        dateFormat: "mm-dd-yyyy HH:MM:ss",
        includeFailureMsg: true,
        logo: `./public/images/govelogo.asset.png`,
        outputPath: `./test/reports/Web-Client-Test-Report.html`,
      },
    ],
  ],
};
module.exports = createJestConfig(customJestConfig);
