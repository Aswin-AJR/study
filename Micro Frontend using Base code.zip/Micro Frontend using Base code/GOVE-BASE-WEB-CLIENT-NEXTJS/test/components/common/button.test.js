/**
@CreatedBy        : Karthick DK
@CreatedTime      : Jan 04 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Jan 04 2022
@Description      : This file contain test suite for button component
**/

/**
 * Import the required test libraries
 */
import "@testing-library/jest-dom";
import { render, screen, fireEvent } from "@testing-library/react";
import { testSuite } from "../../main";
import { Button } from '../../../src/components/common/Button'

/**
 * Import the test data and test component
 */
import { ButtonData } from "./button.data";

/**
 * Initializing the objects for imported classes
 */
let buttonData = new ButtonData();

/**
 * POSITIVE CASES #1
 * Test Data For - TestSuiteID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001] | TestID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001] | ComponentID : [base_web_components_common_button_Create User]
 */
testSuite("TestSuiteID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001] | ComponentID : [base_web_components_common_button_Create User]", () => {
    test(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001.description, async () => {
        render(
            <Button
                configs={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001.input.configs}
                data={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001.input.data}
                callbacks={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001.input.callbacks}
            />
        );
        expect(screen.getByTestId(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001.componentID)).toHaveTextContent(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001.output.buttonLabel)
    });

    test(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC002.description, async () => {
        render(
            <Button
                configs={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC002.input.configs}
                data={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC002.input.data}
                callbacks={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC002.input.callbacks}
            />
        );
        const element = screen.getByTestId(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC002.componentID);
        const spanElements = element.querySelectorAll('span');
        expect(spanElements[0]).toHaveClass(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC002.output.icon);
    });

    test(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC003.description, async () => {
        const handleClick = jest.fn().mockImplementation(() => buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC003.input.callbacks.handleButtonClick)
        render(
            <Button
                configs={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC003.input.configs}
                data={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC003.input.data}
                callbacks={{ handleButtonClick: handleClick }}
            />
        );
        fireEvent.click(screen.getByTestId(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC003.componentID))
        expect(handleClick).toHaveBeenCalledTimes(1)
    });
}, 'base.web.suite.components.common');

/**
 * NEGATIVE CASES #1
 * Test Data For - TestSuiteID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002] | TestID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002_TC001] | ComponentID : [base_web_components_common_base_web_components_common_button_Create User]
 */
testSuite("TestSuiteID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002] | ComponentID : [base_web_components_common_button_Create User]", () => {
    test(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002_TC001.description, async () => {
        render(
            <Button
                configs={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002_TC001.input.configs}
                data={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002_TC001.input.data}
                callbacks={buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002_TC001.input.callbacks}
            />
        );
        const element = screen.queryByTestId(buttonData.BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002_TC001.componentID);
        expect(element).toBeNull();
    });
}, 'base.web.suite.components.common')