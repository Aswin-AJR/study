/**
@CreatedBy        : Karthick DK
@CreatedTime      : Jan 04 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Jan 04 2022
@Description      : This file contain all test data for button component
**/

export class ButtonData {
    /**
     * POSITIVE CASES #1
     * Test Data For - TestSuiteID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001] | TestID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001] | ComponentID : [base_web_components_common_button_Create User]
     */
    BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC001 = {
        description: `Check if the Button is rendered with the label 'Create User'`,
        componentID: "base_web_components_common_button_Create User",
        input: {
            configs: { icon: "pi pi-plus" },
            data: { buttonLabel: "Create User" },
            callbacks: { handleButtonClick: () => { } }
        },
        output: {
            buttonLabel: "Create User"
        }
    }

    BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC002 = {
        description: `Check if the button is rendered with the icon 'plus'`,
        componentID: "base_web_components_common_button_Create User",
        input: {
            configs: { icon: "pi pi-plus" },
            data: { buttonLabel: "Create User" },
            callbacks: { handleButtonClick: () => { } }
        },
        output: {
            icon: "pi pi-plus"
        }
    }

    BASE_WEB_COMPONENTS_COMMON_BUTTON_TS001_TC003 = {
        description: `Check if the button onclick function executes the provided callback function`,
        componentID: "base_web_components_common_button_Create User",
        input: {
            configs: { icon: "pi pi-plus" },
            data: { buttonLabel: "Create User" },
            callbacks: { handleButtonClick: () => { console.info("CREATE USER BUTTON IS SUCCESSFULLY TRIGGERED") } }
        },
        output: {
            consoleMessage: "CREATE USER BUTTON IS SUCCESSFULLY TRIGGERED"
        }
    }

    /**
     * NEGATIVE CASES #1
     * Test Data For - TestSuiteID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002] | TestID: [BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002_TC001] | ComponentID : [base_web_components_common_base_web_components_common_button_Create User]
     */
    BASE_WEB_COMPONENTS_COMMON_BUTTON_TS002_TC001 = {
        description: `Check if the button is not displayed when both the label and icon is passed empty `,
        componentID: "base_web_components_common_button_Create User",
        input: {
            configs: { icon: "" },
            data: { buttonLabel: "" },
            callbacks: { handleButtonClick: () => { } }
        },
        output: {
            buttonLabel: "Create User"
        }
    }
}
