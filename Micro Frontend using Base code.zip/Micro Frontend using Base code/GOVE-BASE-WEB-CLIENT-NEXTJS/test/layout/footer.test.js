/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contain test suite for footer component
**/

/**
 * Import the required test libraries
 */
import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";

/**
 * Import the test data and test component
 */
import { FooterData } from "./footer.data";
import { Footer } from "../../src/layout/Footer";
import { testSuite } from '../main'

/**
 * Initializing the objects for imported classes
 */
let footerData = new FooterData();


testSuite("TestSuiteID: [BASE_WEB_LAYOUT_FOOTER_TS001] | ComponentID : [base_web_layout_footer]", () => {

    test(footerData.FOOTER_COMPONENT_TEST_ID_001.description, async () => {
        render(<Footer
            configs={footerData.FOOTER_COMPONENT_TEST_ID_001.input.configs}
            data={footerData.FOOTER_COMPONENT_TEST_ID_001.input.data}
            callbacks={footerData.FOOTER_COMPONENT_TEST_ID_001.input.callbacks} />);

        expect(screen.getByTestId(footerData.FOOTER_COMPONENT_TEST_ID_001.componentID)).toHaveTextContent(
            footerData.FOOTER_COMPONENT_TEST_ID_001.output.footerText
        );;
    });

}, 'base.web.suite.layout');
