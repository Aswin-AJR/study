/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 2 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 2 2022
@Description      : This file contain all test data for topbar component
**/

export class TopbarData {
    /**
     * Test Data For - TestSuiteID: [BASE_WEB_LAYOUT_TOPBAR_TS001] | TestID: [BASE_WEB_LAYOUT_TOPBAR_TS001_TC001] | ComponentID : [base_web_layout_topbar]
     */
    BASE_WEB_LAYOUT_TOPBAR_TS001_TC001 = {
        description: "Check if the component contains the application title",
        componentID: "base_web_layout_topbar_appname",
        input: {
            configs: {
                sideBarConfig: {
                    isSidebarVisible: true
                },
                appConfig: {
                    appName: "User Management",
                    appLogo: "/favicon.ico",
                    appTheme: { TopbarBackgroundColor: "violet" }
                },
                topbarConfig: {
                    topbarAppLogoWidth: 30,
                    topbarAppLogoHeight: 30,
                    topbarBackgroundColor: 'red'
                }
            },
            data: {
                tenantList: [
                    {
                        "TenantKey": "penske-tenant-key",
                        "TenantName": "Penske",
                        "TenantLogoURL": "https://assets.alitasys.com/logo/tenant/{tenant-key}"
                    },
                    {
                        "TenantKey": "ryder-tenant-key",
                        "TenantName": "Ryder",
                        "TenantLogoURL": "https://assets.alitasys.com/logo/tenant/{tenant-key}"
                    }
                ],
                merchantInfo: {
                    "MerchantKey": "alita-merchant-key",
                    "MerchantName": "Alita",
                    "MerchantLogoURL": "https://assets.alitasys.com/logo/merchant/{merchant-key}"
                },
                instanceInfo: {
                    "EnvironmentName": "DEV"
                },
                userInfo: {
                    "UserKey": "dinessh-user-key",
                    "UserName": "Dinesh",
                    "UserEmail": "dinesh@alitasys.com",
                    "UserType": "CUSTOMER",
                    "UserRole": "SUPER-ADMIN"
                }
            },
            callbacks: null
        },
        output: {
            appName: "User Management",
        }
    }

    /**
     * Test Data For - TestSuiteID: [BASE_WEB_LAYOUT_TOPBAR_TS001] | TestID: [BASE_WEB_LAYOUT_TOPBAR_TS001_TC002] | ComponentID : [base_web_layout_topbar]
     */
    BASE_WEB_LAYOUT_TOPBAR_TS001_TC002 = {
        description: "Check if the component contains the background color as violet",
        componentID: "base_web_layout_topbar_navbar",
        input: {
            configs: {
                sideBarConfig: {
                    isSidebarVisible: true
                },
                appConfig: {
                    appName: "User Management",
                    appLogo: "/favicon.ico",
                    appTheme: { TopbarBackgroundColor: 'violet' }
                },
                topbarConfig: {
                    topbarAppLogoWidth: 30,
                    topbarAppLogoHeight: 30,
                    topbarBackgroundColor: 'violet'
                }
            },
            data: {
                tenantList: [
                    {
                        "TenantKey": "penske-tenant-key",
                        "TenantName": "Penske",
                        "TenantLogoURL": "https://assets.alitasys.com/logo/tenant/{tenant-key}"
                    },
                    {
                        "TenantKey": "ryder-tenant-key",
                        "TenantName": "Ryder",
                        "TenantLogoURL": "https://assets.alitasys.com/logo/tenant/{tenant-key}"
                    }
                ],
                merchantInfo: {
                    "MerchantKey": "alita-merchant-key",
                    "MerchantName": "Alita",
                    "MerchantLogoURL": "https://assets.alitasys.com/logo/merchant/{merchant-key}"
                },
                instanceInfo: {
                    "EnvironmentName": "DEV"
                },
                userInfo: {
                    "UserKey": "dinessh-user-key",
                    "UserName": "Dinesh",
                    "UserEmail": "dinesh@alitasys.com",
                    "UserType": "CUSTOMER",
                    "UserRole": "SUPER-ADMIN"
                }
            },
            callbacks: null
        },
        output: {
            topbarBackgroundColor: "violet",
        }
    }

}
