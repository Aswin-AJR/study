/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contain test suite for topbar component
**/

/**
 * Import the required test libraries
 */
import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import { ProSidebarProvider } from 'react-pro-sidebar';

/**
 * Import the test data and test component
 */
import { TopbarData } from "./topbar.data";
import { Topbar } from "../../src/layout/Topbar";
import { BrowserRouter } from "react-router-dom";
import { testSuite } from '../main'

/**
 * Initializing the objects for imported classes
 */
let topbarData = new TopbarData();


testSuite("TestSuiteID: [BASE_WEB_LAYOUT_TOPBAR_TS001] | ComponentID : [base_web_layout_topbar]", () => {

    test(topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC001.description, async () => {
        render(
            <BrowserRouter>
                <ProSidebarProvider>
                    <Topbar
                        configs={topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC001.input.configs}
                        data={topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC001.input.data}
                        callbacks={topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC001.input.callbacks} />
                </ProSidebarProvider>
            </BrowserRouter>
        );

        expect(screen.getByTestId(topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC001.componentID)).toHaveTextContent(topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC001.output.appName)
    });

    test(topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC002.description, async () => {
        render(
            <BrowserRouter>
                <ProSidebarProvider>
                    <Topbar
                        configs={topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC002.input.configs}
                        data={topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC002.input.data}
                        callbacks={topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC002.input.callbacks} />
                </ProSidebarProvider>
            </BrowserRouter>
        );

        expect(screen.getByTestId(topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC002.componentID)).toHaveStyle(`background-color: ${topbarData.BASE_WEB_LAYOUT_TOPBAR_TS001_TC002.output.topbarBackgroundColor}`)
    });

}, 'base.web.suite.layout');
