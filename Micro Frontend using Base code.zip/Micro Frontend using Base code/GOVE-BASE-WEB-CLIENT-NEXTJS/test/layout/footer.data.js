/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 2 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 2 2022
@Description      : This file contain all test data for footer component
**/

export class FooterData {

    /**
     * Test Data For - TestSuiteID: [TS001] | TestID: [T001] | ComponentName : [Footer]
     */
    FOOTER_COMPONENT_TEST_ID_001 = {
        testID: 1,
        description: "Check if the component contains the footer text",
        componentID: "footer_component",
        input: {
            configs: {
                footerConfig: {
                    footerText: "Powered By Alita"
                }
            },
            data: null,
            callbacks: null
        },
        output: {
            footerText: "Powered By Alita"
        }
    }

}
