/**
* CreatedBy        : Karthick DK
* CreatedTime      : 29 Dec 2022
* ModifiedBy       : Karthick DK
* ModifiedTime     : 29 Dec 2022
* Description      : This file will handle the jest setup
**/


/**
 * Importing all modules required
 */
/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 29 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : DEc 29 2022
@Description      : This file will handle enable/disable in test suite
**/


const testConfig = require('../test.config.json');

const testSuite = (suiteName, callback, layerName) => {
    const suite = testConfig[layerName]?.find((s) => s.suiteName === suiteName);
    if (!suite || !suite.isSuiteEnabled) {
        describe.skip(suiteName, callback);
    } else {
        describe(suiteName, callback);
    }
};
module.exports = { testSuite };