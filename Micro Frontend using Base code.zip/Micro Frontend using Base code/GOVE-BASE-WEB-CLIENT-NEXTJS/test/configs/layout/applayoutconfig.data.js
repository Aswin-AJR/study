/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 2 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 2 2022
@Description      : This file contain all test data for App Layout Config
**/

export class AppLayoutConfigData {
    /**
     * Test Data For - TestSuiteID: [BASE_WEB_CONFIG_LAYOUT_APPLAYOUTCONFIG_TS001] | TestID: [BASE_WEB_CONFIG_LAYOUT_APPLAYOUTCONFIG_TS001_TC001] | ConfigurationID : [base_web_config_layout_applayoutconfig]
     */
    BASE_WEB_CONFIG_LAYOUT_APPLAYOUTCONFIG_TS001_TC001 = {
        description: "Check if the app layout config contains the topbar background color as #1f1044, app name as 'User Management'",
        configID: "TOPBAR_BACKGROUND_COLOR",
        input: {},
        output: {
            IS_FOOTER_VISIBLE: true,
            IS_TOPBAR_VISIBLE: true,
            IS_SIDEBAR_VISIBLE: true
        }
    }
}
