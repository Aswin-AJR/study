/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contain test suite for applayoutconfig
**/

/**
 * Import the required test libraries
 */
import "@testing-library/jest-dom";

/**
 * Import the test data and test component
 */
import { AppLayoutConfigData } from "./applayoutconfig.data";
import { AppLayoutConfig } from "../../../src/configs/layout/AppLayoutConfig"
import { testSuite } from '../../main'

/**
 * Initializing the objects for imported classes
 */
let appLayoutConfigData = new AppLayoutConfigData();
let appLayoutConfig = new AppLayoutConfig()

testSuite("TestSuiteID: [BASE_WEB_CONFIG_LAYOUT_APPLAYOUT_TS001] | ConfigID : [base_web_config_layout_applayoutconfig]", () => {

    it(appLayoutConfigData.BASE_WEB_CONFIG_LAYOUT_APPLAYOUTCONFIG_TS001_TC001.description, async () => {
        expect(appLayoutConfig.APP_LAYOUT_CONFIG.IS_FOOTER_VISIBLE).toBe(appLayoutConfigData.BASE_WEB_CONFIG_LAYOUT_APPLAYOUTCONFIG_TS001_TC001.output.IS_FOOTER_VISIBLE)
        expect(appLayoutConfig.APP_LAYOUT_CONFIG.IS_SIDEBAR_VISIBLE).toBe(appLayoutConfigData.BASE_WEB_CONFIG_LAYOUT_APPLAYOUTCONFIG_TS001_TC001.output.IS_SIDEBAR_VISIBLE)
        expect(appLayoutConfig.APP_LAYOUT_CONFIG.IS_TOPBAR_VISIBLE).toBe(appLayoutConfigData.BASE_WEB_CONFIG_LAYOUT_APPLAYOUTCONFIG_TS001_TC001.output.IS_TOPBAR_VISIBLE)

    });

}, 'base.web.suite.configs');
