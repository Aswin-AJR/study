/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 20 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Dec 20 2022
@Description      : This file contain test suite for users page
**/

/**
 * Import the required test libraries
 */
import "@testing-library/jest-dom";
import { render, screen, waitFor } from "@testing-library/react";

/**
 * Import the test data and test component
 */
import { UserIndexData } from "./index.data";
import UserIndex from '../../../src/pages/users/index'
import { UserAuthContextProvider } from "../../../src/utils/context/UserAuthContextProvider";
import { testSuite } from '../../main'

/**
 * Initializing the objects for imported classes
 */
let userIndexData = new UserIndexData();
jest.mock('next/router', () => require('next-router-mock'));
jest.mock('next/dist/client/router', () => require('next-router-mock'));


testSuite("TestSuiteID: [BASE_WEB_PAGES_USERS_USERINDEX_TS001] | ComponentID : [base_web_pages_users_userindex]", () => {

    test(userIndexData.BASE_WEB_PAGES_USERS_USERINDEX_TS001_TC001.description, async () => {
        render(
            <UserAuthContextProvider value={userIndexData.BASE_WEB_PAGES_USERS_USERINDEX_TS001_TC001.input.isUserAuthenticated}>
                <UserIndex />
            </UserAuthContextProvider>
        );

        await waitFor(() => {
            expect(screen.getByTestId(userIndexData.BASE_WEB_PAGES_USERS_USERINDEX_TS001_TC001.output.user_index_top_zone_component_id)).toBeInTheDocument();
            expect(screen.getByTestId(userIndexData.BASE_WEB_PAGES_USERS_USERINDEX_TS001_TC001.output.user_index_bottom_zone_component_id)).toBeInTheDocument();
        });

    });
}, 'base.web.suite.pages');
