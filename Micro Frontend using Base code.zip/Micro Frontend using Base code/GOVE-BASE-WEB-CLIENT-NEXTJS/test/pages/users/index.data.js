/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 12 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Dec 12 2022
@Description      : This file contain all test data for user index page
**/

export class UserIndexData {
    /**
     * Test Data For - TestSuiteID: [BASE_WEB_PAGES_USERS_USERINDEX_TS001] | TestID: [BASE_WEB_PAGES_USERS_USERINDEX_TS001_TC001] | ComponentID : [base_web_pages_users_userindex]
     */
    BASE_WEB_PAGES_USERS_USERINDEX_TS001_TC001 = {
        description: "Check if the users page contains two zones (User index top zone & User index bottom zone)",
        componentID: "base_web_pages_users_userindex",
        input: {
            isUserAuthenticated: true
        },
        output: {
            user_index_top_zone_component_id: 'base_web_zones_users_userindex_userindextopzone_container',
            user_index_bottom_zone_component_id: 'base_web_zones_users_userindex_userindexbottomzone_userlist_table'
        }
    }
}
