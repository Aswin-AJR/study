/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 20 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Dec 20 2022
@Description      : This file contain test suite for private route
**/

/**
 * Import the required test libraries
 */
import "@testing-library/jest-dom";
import { render, screen, waitFor, within } from "@testing-library/react";
import { UserIndexBottomZone } from "../../../../src/zones/users/userindex/UserIndexBottomZone";
import { testSuite } from '../../../main'

/**
 * Import the test data and test component
 */
import { UserIndexBottomZoneData } from "./userindexbottomzone.data";

/**
 * Initializing the objects for imported classes
 */
let userIndexBottomZoneData = new UserIndexBottomZoneData();

testSuite("TestSuiteID: [BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001] | ComponentID : [base_web_zones_users_userindex_userindexbottomzone_userlist_table]", () => {

    test(userIndexBottomZoneData.BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001.description, async () => {
        render(
            <UserIndexBottomZone
                configs={userIndexBottomZoneData.BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001.input.configs}
                data={userIndexBottomZoneData.BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001.input.data}
                callbacks={userIndexBottomZoneData.BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001.input.callbacks}
            />
        );
        await waitFor(() => {
            // GETTING THE USER LIST TABLE
            const userListTable = screen.getByTestId(userIndexBottomZoneData.BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001.componentID)
            // GETTING THE USER LIST TABLE HEADER
            const userListTableHeader = within(userListTable).getByTestId(userIndexBottomZoneData.BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001.input.header_row_data_test_id)
            // CHECKING USER LIST TABLE COLUMN COUNT
            expect(userListTableHeader.children.length).toBe(userIndexBottomZoneData.BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001.output.userListTableHeader.length)
            within(userListTableHeader).getAllByRole('columnheader').map((header, index) => {
                // CHECKING USER LIST TABLE COLUMN NAME
                expect(header.innerHTML === userIndexBottomZoneData.BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001.output.userListTableHeader[index]).toEqual(true)
            })
        });
    });
}, 'base.web.suite.zones');
