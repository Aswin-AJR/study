/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 12 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Dec 12 2022
@Description      : This file contain all test data for user index bottom zone 
**/

import userListMock from '../../../../src/mocks/UserMock.json'

export class UserIndexBottomZoneData {
    /**
     * Test Data For - TestSuiteID: [BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001] | TestID: [BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001] | ComponentID : [base_web_zones_users_userindex_userindexbottomzone_userlist_table]
     */
    BASE_WEB_ZONES_USERS_USERINDEX_USERINDEXBOTTOMZONE_TS001_TC001 = {
        description: `
            1. Check the Column Count of the user list table in user index bottom zone
            2. Check the Column Names of the user list table in user index bottom zone
        `,
        componentID: "base_web_zones_users_userindex_userindexbottomzone_userlist_table",
        input: {
            header_row_data_test_id: "base_web_components_common_table_user_list_tableheader_headerrow",
            configs: {
                features: {
                    isListUsersFeatureActive: true
                },
                languageConfig: {}
            },
            data: {
                userList: userListMock
            },
            callbacks: {}
        },
        output: {
            userListTableHeader: ["User ID", "Name", "Role", "Address", "Email ID", "Organization", "Created Time"]
        }
    }
}
