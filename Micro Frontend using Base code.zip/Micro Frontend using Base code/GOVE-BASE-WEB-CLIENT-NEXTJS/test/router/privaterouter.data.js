/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 12 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Dec 12 2022
@Description      : This file contain all test data for private route for this application
**/

export class PrivateRouteData {
    /**
     * Test Data For - TestSuiteID: [BASE_WEB_ROUTER_PRIVATEROUTE_TS001] | TestID: [BASE_WEB_ROUTER_PRIVATEROUTE_TS001_TC001] | ComponentID : [base_web_router_privaterouter]
     */
    BASE_WEB_ROUTER_PRIVATEROUTE_TS001_TC001 = {
        description: "Check if the authenticated user able to access users page",
        componentID: "base_web_router_privaterouter",
        input: {
            isUserAuthenticated: true
        },
        output: {
            user_index_page_id: "base_web_pages_users_userindex",
        }
    }

    /**
     * Test Data For - TestSuiteID: [BASE_WEB_ROUTER_PRIVATEROUTE_TS001] | TestID: [BASE_WEB_ROUTER_PRIVATEROUTE_TS001_TC002] | ComponentID : [base_web_router_privaterouter]
     */
    BASE_WEB_ROUTER_PRIVATEROUTE_TS001_TC002 = {
        description: "Check if the unauthenticated user is redirected to login page while try to access users page",
        componentID: "base_web_router_privaterouter",
        input: {
            isUserAuthenticated: false
        },
        output: {
            signin_page_id: 'base_web_pages_signin_signinindex',
        }
    }
}
