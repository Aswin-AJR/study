/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 20 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Dec 20 2022
@Description      : This file contain test suite for private route
**/

/**
 * Import the required test libraries
 */
import "@testing-library/jest-dom";
import { render, screen, waitFor } from "@testing-library/react";
import { testSuite } from '../main'

/**
 * Import the test data and test component
 */
import { UserAuthContextProvider } from "../../src/utils/context/UserAuthContextProvider";
import UserIndex from "../../src/pages/users";
import { PrivateRouteData } from "./privaterouter.data";

/**
 * Initializing the objects for imported classes
 */
let privateRouteData = new PrivateRouteData();
jest.mock('next/router', () => require('next-router-mock'));
jest.mock('next/dist/client/router', () => require('next-router-mock'));


testSuite("TestSuiteID: [BASE_WEB_ROUTER_PRIVATEROUTE_TS001] | ComponentID : [base_web_router_privaterouter]", () => {

    test(privateRouteData.BASE_WEB_ROUTER_PRIVATEROUTE_TS001_TC001.description, async () => {
        render(
            <UserAuthContextProvider value={privateRouteData.BASE_WEB_ROUTER_PRIVATEROUTE_TS001_TC001.input.isUserAuthenticated}>
                <UserIndex />
            </UserAuthContextProvider>
        );
        await waitFor(() => {
            expect(screen.getByTestId(privateRouteData.BASE_WEB_ROUTER_PRIVATEROUTE_TS001_TC001.output.user_index_page_id)).toBeTruthy();
        });
    });
}, 'base.web.suite.router');
