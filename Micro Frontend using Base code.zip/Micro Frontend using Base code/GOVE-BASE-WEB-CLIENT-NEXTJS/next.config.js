/**
@CreatedBy        : Aswin Joseph Raj
@CreatedTime      : Jan 23 2023
@ModifiedBy       : Aswin Joseph Raj
@ModifiedTime     : Jan 23 2023
@Description      : This file contain all the next js configuration
**/

/** @type {import('next').NextConfig} */

/**
 * Remote applist add
 */
const NextFederationPlugin = require("@module-federation/nextjs-mf");
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  webpack: (config, options) => {
    config.plugins.push(
      new NextFederationPlugin({
        name: "App1", /** */
        filename: "static/chunks/remoteEntry.js",
        exposes: {
          './PAGES': "./src/exposes/exposes.tsx"
        },
        remotes: {},
        shared: {},
        extraOptions: {
          automaticAsyncBoundary: true,
        },
      })
    );
    return config;
  },
};
module.exports = nextConfig;

