declare module 'next/router';
declare module "styled-components";
declare module "../node_modules/basesdk";
declare module "lodash";
declare module "ga-4-react";
declare module "react-pro-sidebar";
declare module 'next/image';
declare module '@gove/logger'
