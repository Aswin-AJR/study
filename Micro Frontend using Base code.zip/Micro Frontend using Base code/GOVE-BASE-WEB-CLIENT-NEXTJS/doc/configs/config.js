/**
@CreatedBy        : Karthick DK
@CreatedTime      : Nov 17 2022
@Description      : This file contains all the enviroment configurations for web client
**/

module.exports = class config {

  WEB_CLIENT_HOST = "localhost";
  WEB_CLIENT_PORT = 3000;
  WEB_CLIENT_SECURITY_ENABLED = "true";
  WEB_CLIENT_SECURITY_KEY_FILE_PATH = "C:/Softwares/Cert/privateKey.key";
  WEB_CLIENT_SECURITY_CERT_FILE_PATH = "C:/Softwares/Cert/certificate.crt";

  GATEWAY_URL = " http://localhost:3100";

};
