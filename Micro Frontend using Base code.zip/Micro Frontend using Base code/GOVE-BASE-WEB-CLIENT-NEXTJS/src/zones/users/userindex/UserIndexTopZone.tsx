import React, { useContext } from 'react'
import { Button } from '../../../components/common/Button'
import { SearchBar } from '../../../components/common/SearchBar'
import styled from 'styled-components'
import { useRouter } from 'next/router'
import { UserIndexTopZoneInterface } from '../../../interface/zones/users/userindex/UserIndexTopZoneInterface'
import { useTranslate } from '../../../utils/hooks/useTranslate'
import { LocaleSettingsContext } from '../../../pages/_app'

const Row = styled.div`
    @media screen and (max-width: 990px) {
        #user-list-top-zone-searchbar{
            order: 2
        }
        #user-list-top-zone-create-user{
            order: 1;
            margin-bottom: 10px;
        }
    }
    @media screen and (min-width: 991px) {
        #user-list-top-zone-searchbar{
            order: 1
        }
        #user-list-top-zone-create-user{
            order: 2
        }
    }
`
function UserIndexTopZone(props: UserIndexTopZoneInterface) {

    const localeSettings = useContext<any>(LocaleSettingsContext);
    const router = useRouter()
    const { translate } = useTranslate(
        {
            languageConfig: props?.configs?.languageConfig,
            displayLanguage: localeSettings?.DisplayLanguage
        }
    )

    const handleSearch = (searchKeyword: string) => {
        console.info('USERS SEARCH KEYWORD', searchKeyword)
    }

    return (
        <Row className='row mb-2' data-testid="base_web_zones_users_userindex_userindextopzone_container">
            <div className="col-lg-10 col-md-12 col-sm-12" id='user-list-top-zone-searchbar' data-testid="base_web_zones_users_userindex_userindextopzone_searchbar">
                {props?.configs?.features?.isSearchUserFeatureActive &&
                    <SearchBar
                        configs={{
                            placeholder: translate('Enter User name to search...'),
                            onInputSearchEnabled: false
                        }}
                        data={{
                            defaultValue: ''
                        }}
                        callbacks={{
                            handleSearch: (searchKeyword: string) => handleSearch(searchKeyword)
                        }}
                    />
                }
            </div>
            <div className="col-lg-2 col-md-12 col-sm-12 text-end" id='user-list-top-zone-create-user' data-testid="base_web_zones_users_userindex_userindextopzone_createuser_button">
                {props?.configs?.features?.isCreateUserFeatureActive &&
                    <Button
                        configs={{
                            icon: "pi pi-plus"
                        }}
                        data={{
                            buttonLabel: translate("Create User")
                        }}
                        callbacks={{
                            handleButtonClick: () => router.push('/users/createuser')
                        }}
                    />
                }
            </div>
        </Row>
    )
}

export { UserIndexTopZone }