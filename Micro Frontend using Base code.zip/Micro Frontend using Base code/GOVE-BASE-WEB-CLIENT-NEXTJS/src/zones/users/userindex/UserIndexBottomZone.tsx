import { useRouter } from 'next/router';
import React, { useContext } from 'react'
import { Table } from '../../../components/common/Table';
import { UserListConfig } from '../../../configs/zones/users/userlist/UserListConfig';
import {UserIndexBottomZoneInterface} from '../../../interface/zones/users/userindex/UserIndexBottomZoneInterface'
import { LocaleSettingsContext } from '../../../pages/_app';
import { useTranslate } from '../../../utils/hooks/useTranslate';

/**
 * Initializing the objects for imported classes
 */


function UserIndexBottomZone(props: UserIndexBottomZoneInterface) {

    const localeSettings = useContext<any>(LocaleSettingsContext);
    const router = useRouter()
    const { translate } = useTranslate(
        {
            languageConfig: props?.configs?.languageConfig,
            displayLanguage: localeSettings?.DisplayLanguage
        }
    )
    let userListConfig = new UserListConfig(translate)

    const handleOnClick = (clickedRecord: any) => {
        router.push(`/users/${clickedRecord.UserID}`)
    };

    const handleTableScroll = () => {
        return props?.data?.userList
    };

    return (
        <div data-testid="base_web_zones_users_userindex_userindexbottomzone_userlist_table">
            {props?.configs?.features?.isListUsersFeatureActive &&
                <Table
                    configs={{
                        headerSettings: userListConfig.getTableHeaderConfig(),
                        tableName: 'user_list',
                        hasMoreRecords: false,
                        isHoverable: false,
                        isStriped: false,
                        isDark: false,
                        isBordered: true
                    }}
                    data={props?.data?.userList}
                    callbacks={{
                        handleOnClick: (clickedRecord: any) => handleOnClick(clickedRecord),
                        handleTableScroll: handleTableScroll()
                    }}
                />
            }
        </div>
    )
}

export { UserIndexBottomZone }