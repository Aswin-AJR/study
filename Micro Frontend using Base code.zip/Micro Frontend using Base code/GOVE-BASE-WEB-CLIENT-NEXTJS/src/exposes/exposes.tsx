import { Footer } from "../layout/Footer";
import { Sidebar } from "../layout/Sidebar";
import { Topbar } from "../layout/Topbar";
import Index from "../pages/index";



// eslint-disable-next-line import/no-anonymous-default-export, import/no-default-export
export default {
    Home: Index,
    Sidebar: Sidebar,
    Topbar: Topbar,
    Footer: Footer
} 