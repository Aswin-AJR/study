/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contains all configs for user index page
**/


class UserListConfig {
    translate: Function
    constructor(translate: Function) {
        this.translate = translate
    }

    getTableHeaderConfig() {
        return [
            {
                title: this.translate("User ID"),
                handler: "handleOnChange",
                type: "text",
                width: "8px",
                render: (rowData: any) => {
                    return <span>{rowData.UserID}</span>;
                },
            },
            {
                title: this.translate("Name"),
                handler: "handleOnChange",
                type: "text",
                width: "10px",
                render: (rowData: any) => {
                    return <span>{rowData.UserName}</span>;
                },
            },
            {
                title: this.translate("Role"),
                handler: "handleOnChange",
                type: "text",
                width: "10px",
                render: (rowData: any) => {
                    return <span>{rowData.UserRole}</span>;
                },
            },
            {
                title: this.translate("Address"),
                handler: "handleOnChange",
                type: "text",
                width: "10px",
                render: (rowData: any) => {
                    return <span>{rowData.UserAddress}</span>;
                },
            },
            {
                title: this.translate("Email ID"),
                handler: "handleOnChange",
                type: "text",
                width: "10px",
                render: (rowData: any) => {
                    return <span>{rowData.UserEmail}</span>;
                },
            },
            {
                title: this.translate("Organization"),
                handler: "handleOnChange",
                type: "text",
                width: "10px",
                render: (rowData: any) => {
                    return <span>{rowData.UserOrganization}</span>;
                },
            },
            {
                title: this.translate("Created Time"),
                handler: "handleOnChange",
                type: "text",
                width: "10px",
                render: (rowData: any) => {
                    return <span>{rowData.CreatedTime}</span>;
                },
            },
        ];
    }

}

export { UserListConfig }
