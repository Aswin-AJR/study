/**
@CreatedBy        : Aswin Joseph Raj S
@CreatedTime      : Jan 19 2023
@ModifiedBy       : Aswin Joseph Raj S
@ModifiedTime     : Jan 19 2023
@Description      : This file contains config for sidebar component
**/

import React from "react"
import { DashboardOutlined, UserOutlined, UserAddOutlined, UserDeleteOutlined, SettingOutlined } from "@ant-design/icons";


class SidebarConfig {

    SIDEBAR_CONFIG = {
        SIDEBAR_APP_LOGO_WIDTH: 30,
        SIDEBAR_APP_LOGO_HEIGHT: 30,
        SIDEBAR_ICON_THEME: "google" // ["google", "antDesign"]
    }

    GET_SIDEBAR_MENU_CONFIG(menuSettings: any = null) {
        return [
            {
                menuName: 'Dashboard',
                menuDisplayName: !menuSettings ? 'Dashboard' : menuSettings['Dashboard']?.MenuDisplayName,
                menuKey: 1,
                menuPath: "/dashboard",
                menuIcon: this.SIDEBAR_CONFIG.SIDEBAR_ICON_THEME === "google"
                    ? React.createElement(
                        "span",
                        { className: "material-icons" },
                        "dashboard"
                    )
                    : React.createElement(DashboardOutlined),
                subMenus: undefined,
                isMenuEnabled: !menuSettings ? true : menuSettings['Dashboard']?.IsMenuEnabled
            },
            {
                menuName: 'User',
                menuDisplayName: !menuSettings ? 'User' : menuSettings['User']?.MenuDisplayName,
                menuKey: 2,
                menuPath: "/user",
                menuIcon: this.SIDEBAR_CONFIG.SIDEBAR_ICON_THEME === "google"
                    ? React.createElement(
                        "span",
                        { className: "material-icons" },
                        "person"
                    )
                    : React.createElement(UserOutlined),
                subMenus: [
                    {
                        menuName: 'Create User',
                        menuDisplayName: !menuSettings ? 'Create User' : menuSettings?.['User'].SubMenus?.['Create User']?.MenuDisplayName,
                        menuKey: 2.1,
                        menuPath: "/user/create",
                        menuIcon: this.SIDEBAR_CONFIG.SIDEBAR_ICON_THEME === "google"
                            ? React.createElement(
                                "span",
                                { className: "material-icons" },
                                "person_add"
                            )
                            : React.createElement(UserAddOutlined),
                        subMenus: undefined,
                        isMenuEnabled: !menuSettings ? true : menuSettings?.['User'].SubMenus?.['Create User']?.IsMenuEnabled
                    },
                    {
                        menuName: 'Delete User',
                        menuDisplayName: !menuSettings ? 'Delete User' : menuSettings?.['User'].SubMenus?.['Delete User']?.MenuDisplayName,
                        menuKey: 2.2,
                        menuPath: "/user/delete",
                        menuIcon: this.SIDEBAR_CONFIG.SIDEBAR_ICON_THEME === "google"
                            ? React.createElement(
                                "span",
                                { className: "material-icons" },
                                "person_remove"
                            )
                            : React.createElement(UserDeleteOutlined),
                        subMenus: undefined,
                        isMenuEnabled: !menuSettings ? true : menuSettings?.['User'].SubMenus?.['Delete User']?.IsMenuEnabled
                    }
                ],
                isMenuEnabled: !menuSettings ? true : menuSettings['User']?.IsMenuEnabled
            },
            {
                menuName: 'Settings',
                menuDisplayName: !menuSettings ? 'Settings' : menuSettings['Settings']?.MenuDisplayName,
                menuKey: 3,
                menuPath: "/settings",
                menuIcon: this.SIDEBAR_CONFIG.SIDEBAR_ICON_THEME === "google"
                    ? React.createElement(
                        "span",
                        { className: "material-icons" },
                        "settings"
                    )
                    : React.createElement(SettingOutlined),
                subMenus: undefined,
                isMenuEnabled: !menuSettings ? true : menuSettings['Settings']?.IsMenuEnabled
            }
        ]
    }


}
export { SidebarConfig }
