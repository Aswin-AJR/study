/**
@CreatedBy        : Aswin Joseph Raj S
@CreatedTime      : Jan 19 2023
@ModifiedBy       : Aswin Joseph Raj S
@ModifiedTime     : Jan 19 2023
@Description      : This file contains config for Topbar component
**/

import React from "react"



class TopbarConfig {

    TOPBAR_CONFIG = {
        TOPBAR_FONT_COLOR: 'white',
        TOPBAR_APP_LOGO_WIDTH: 30,
        TOPBAR_APP_LOGO_HEIGHT: 30
    }

    GET_TOPBAR_MENU_CONFIG() {
        return [
            {
                menuName: 'Users',
                menuDisplayName: 'Users',
                menuKey: 1,
                menuPath: "/users",
                menuIcon: React.createElement("i", { className: "pi pi-clone me-2 text-white" }),
                subMenus: undefined,
                isMenuEnabled: true,
                isMenuVisible: true
            },
            {
                menuName: 'Session',
                menuDisplayName: 'Session',
                menuKey: 2,
                menuPath: "/session",
                menuIcon: React.createElement("i", { className: "pi pi-clone me-2 text-white" }),
                subMenus: undefined,
                isMenuEnabled: true,
                isMenuVisible: true
            },
            {
                menuName: 'Attendence',
                menuDisplayName: 'Attendence',
                menuKey: 3,
                menuPath: "",
                menuIcon: React.createElement("i", { className: "pi pi-clone me-2 text-white" }),
                subMenus: [
                    {
                        menuName: 'On Duty',
                        menuDisplayName: 'On Duty',
                        menuKey: 3.1,
                        menuPath: "/attendence/onduty",
                        menuIcon: React.createElement("i", { className: "pi pi-clone me-2 text-white" }),
                        subMenus: undefined,
                        isDividerVisibleAtBottom: false,
                        isMenuEnabled: true,
                        isMenuVisible: true
                    },
                    {
                        menuName: 'Workdays',
                        menuDisplayName: 'Workdays',
                        menuKey: 3.2,
                        menuPath: "/attendence/workdays",
                        menuIcon: React.createElement("i", { className: "pi pi-clone me-2 text-white" }),
                        subMenus: undefined,
                        isDividerVisibleAtBottom: true,
                        isMenuEnabled: true,
                        isMenuVisible: true
                    },
                    {
                        menuName: 'Holidays',
                        menuDisplayName: 'Holidays',
                        menuKey: 3.3,
                        menuPath: "/attendence/holidays",
                        menuIcon: React.createElement("i", { className: "pi pi-clone me-2 text-white" }),
                        subMenus: undefined,
                        isDividerVisibleAtBottom: false,
                        isMenuEnabled: true,
                        isMenuVisible: true
                    }
                ],
                isMenuEnabled: true,
                isMenuVisible: true
            }
        ]
    }

}
export { TopbarConfig }