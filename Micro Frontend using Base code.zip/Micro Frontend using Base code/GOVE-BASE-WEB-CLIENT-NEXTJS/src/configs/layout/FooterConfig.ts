/**
@CreatedBy        : Aswin Joseph Raj S
@CreatedTime      : Jan 19 2023
@ModifiedBy       : Aswin Joseph Raj S
@ModifiedTime     : Jan 19 2023
@Description      : This file contains config for sidebar component
**/



class FooterConfig {

    FOOTER_CONFIG = {
        IS_FOOTER_VISIBLE: true,
        FOOTER_FONT_COLOR: 'white',
        FOOTER_TEXT: "Powered By Alita"
    }

}
export { FooterConfig }
