/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contains config for theme component
**/

class AppLayoutConfig {
    APP_LAYOUT_CONFIG = {
        IS_FOOTER_VISIBLE: true,
        IS_TOPBAR_VISIBLE: true,
        IS_SIDEBAR_VISIBLE: true
    }

}

export { AppLayoutConfig }
