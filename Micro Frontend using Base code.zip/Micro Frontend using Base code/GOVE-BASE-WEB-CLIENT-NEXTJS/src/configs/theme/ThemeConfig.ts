/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contains config for theme component
**/

class ThemeConfig {

    //Admin Theme Config
    THEME_CONFIG = {
        ThemeName: "Default Theme",
        FontFamily: "calibri",
        FontSize: "14px",
        AppPrimaryColor: "#1f1044",
        TopbarBackgroundColor: "#1f1044",
        TopbarFontColor: "White",
        SidebarBackgroundColor: "whitesmoke",
        SidebarFontColor: "Black",
        BodyBackgroundColor: "White",
        BodyFontColor: "Black",
        FooterBackgroundColor: "Whitesmoke",
        FooterFontColor: "Black",
        IsThemeChoosen: true
    }
}

export { ThemeConfig }
