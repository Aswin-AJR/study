/**
@CreatedBy        : Karthick
@CreatedTime      : Dec 23 2022
@ModifiedBy       : Karthick
@ModifiedTime     : Dec 23 2022
@Description      : This file contains config for user edit page
**/

class EditUserConfig {

    EDIT_USER_PAGE_DEFAULT_CONFIG = {
        PageID: "page.web.pages.users.edituser",
        PageName: "Edit User Page",
        PageRoute: "/users/edituser",
    }

}

export { EditUserConfig }
