/**
@CreatedBy        : Karthick
@CreatedTime      : Dec 23 2022
@ModifiedBy       : Karthick
@ModifiedTime     : Dec 23 2022
@Description      : This file contains config for user index page
**/

class UserIndexConfig {

    USER_INDEX_PAGE_DEFAULT_CONFIG = {
        PageID: "page.web.pages.users.index",
        PageName: "Users List Page",
        PageRoute: "/users",
    }

    USER_INDEX_PAGE_LANGUAGE_CONFIG = {
        "userIndexTopZone_lang_config": {
            "Enter User name to search...": {
                "en": "Enter Username to search...",
                "ar": "أدخل اسم المستخدم للبحث ...",
                "ta": "தேட பயனர் பெயரை உள்ளிடவும்..."
            },
            "Create User": {
                "en": "Create User",
                "ar": "إنشاء مستخدم",
                "ta": "பயனர்களை உருவாக்கு"
            }
        },
        "userIndexBottomZone_lang_config": {
            "User ID": {
                "en": "User ID",
                "ar": "معرف المستخدم",
                "ta": "பயனர் ஐடி"
            },
            "Name": {
                "en": "Name",
                "ar": "نحن",
                "ta": "பெயர்"
            },
            "Role": {
                "en": "Role",
                "ar": "دور",
                "ta": "பங்கு"
            },
            "Address": {
                "en": "Address",
                "ar": "تبوكتبوك",
                "ta": "முகவரி"
            },
            "Email ID": {
                "en": "Email ID",
                "ar": "عنوان الايميل",
                "ta": "மின்னஞ்சல் முகவரி"
            },
            "Organization": {
                "en": "Organization",
                "ar": "منظمة",
                "ta": "அமைப்பு"
            },
            "Created Time": {
                "en": "Created Time",
                "ar": "وقت الإنشاء",
                "ta": "உருவாக்கப்பட்ட நேரம்"
            }
        }
    }

}

export { UserIndexConfig }
