/**
@CreatedBy        : Karthick
@CreatedTime      : Dec 23 2022
@ModifiedBy       : Karthick
@ModifiedTime     : Dec 23 2022
@Description      : This file contains config for create user page
**/

class CreateUserConfig {

    CREATE_USER_PAGE_DEFAULT_CONFIG = {
        PageID: "page.web.pages.users.createuser",
        PageName: "Create User Page",
        PageRoute: "/users/createuser",
    }

}

export { CreateUserConfig }
