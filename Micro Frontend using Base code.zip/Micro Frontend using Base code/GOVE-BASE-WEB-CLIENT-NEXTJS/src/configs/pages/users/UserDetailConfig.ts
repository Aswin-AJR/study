/**
@CreatedBy        : Karthick
@CreatedTime      : Dec 23 2022
@ModifiedBy       : Karthick
@ModifiedTime     : Dec 23 2022
@Description      : This file contains config for user detail page
**/

class UserDetailConfig {

    USER_DETAIL_PAGE_DEFAULT_CONFIG = {
        PageID: "page.web.pages.users.userdetail",
        PageName: "User Detail Page",
        PageRoute: "/users/{userID}",
    }

}

export { UserDetailConfig }
