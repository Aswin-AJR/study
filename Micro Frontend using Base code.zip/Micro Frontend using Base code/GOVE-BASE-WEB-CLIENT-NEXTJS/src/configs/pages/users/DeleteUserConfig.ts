/**
@CreatedBy        : Karthick
@CreatedTime      : Dec 23 2022
@ModifiedBy       : Karthick
@ModifiedTime     : Dec 23 2022
@Description      : This file contains config for user delete page
**/

class DeleteUserConfig {

    DELETE_USER_PAGE_DEFAULT_CONFIG = {
        PageID: "page.web.pages.users.deleteuser",
        PageName: "Delete User Page",
        PageRoute: "/users/deleteuser",
    }

}

export { DeleteUserConfig }
