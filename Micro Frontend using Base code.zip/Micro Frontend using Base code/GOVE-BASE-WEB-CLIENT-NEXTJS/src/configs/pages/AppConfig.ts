/**
@CreatedBy        : Karthick
@CreatedTime      : Dec 29 2022
@ModifiedBy       : Karthick
@ModifiedTime     : Dec 29 2022
@Description      : This file contains config for app file
**/
import featureConfig from '../../../feature.config.json'

class AppConfig {

    PUBLIC_ROUTES_WITHOUT_PRIVATE_APP_LAYOUT: (string)[] = ['/signin']
    USER_RESTRICTED_ROUTES: (string | null)[] = []

    //Application Theme Config
    APP_CONFIG = {
        APP_LOGO: "/favicon.ico",
        APP_NAME: "Document Management"
    }

    APP_THEME_CONFIG = {
        SIDEBAR_BACKGROUND_COLOR: 'whitesmoke',
        TOPBAR_BACKGROUND_COLOR: '#1f1044'
    }

    constructor() {
        const userRestrictedRoutes = Object.values(featureConfig)
            .map(group => Object.values(group))
            .flat()
            .filter(feature => !feature.isFeatureActive && feature.featureURL)
            .map(feature => feature.featureURL)
            .filter(url => url !== null);
        this.USER_RESTRICTED_ROUTES = userRestrictedRoutes
    }
}

export { AppConfig }
