/**
@CreatedBy        : Karthick
@CreatedTime      : Dec 23 2022
@ModifiedBy       : Karthick
@ModifiedTime     : Dec 23 2022
@Description      : This file contains config for index page
**/

class IndexConfig {

    INDEX_PAGE_DEFAULT_CONFIG = {
        PageID: "page.web.pages.index",
        PageName: "Home Page",
        PageRoute: "/",
    }

}

export { IndexConfig }
