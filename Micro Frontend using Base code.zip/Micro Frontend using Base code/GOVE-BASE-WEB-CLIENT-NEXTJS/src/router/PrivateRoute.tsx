/**
@CreatedBy        : Karthick DK
@CreatedTime      : Nov 17 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 08 2022
@Description      : This file contains all the routing information about the application
**/

/**
 * Importing required modules
 */
import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { useAuth } from '../utils/context/UserAuthContextProvider';
import { PrivateRouteInterface } from '../interface/pages/router/PrivateRouterInterface'

function PrivateRoute(props: PrivateRouteInterface) {
    const router = useRouter();
    const { isUserAuthenticated } = useAuth();

    useEffect(() => {
        // Replace this with a call to your authentication service
        const checkAuth = async () => { };
        checkAuth();
    }, []);

    if (!router) {
        return <div>Loading...</div>
    }

    else if (!isUserAuthenticated) {
        router?.push('/signin');
    }

    return <div data-testid='base_web_router_privaterouter'>{props?.children}</div>;
}

export { PrivateRoute }
