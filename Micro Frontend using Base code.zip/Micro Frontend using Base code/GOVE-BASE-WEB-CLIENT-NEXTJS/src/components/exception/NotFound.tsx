/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 12 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : DEc 12 2022
@Description      : This file is the default component to render when there is no match found
**/

/**
 * Importing all the classes and modules
 */


/**
 * Initializing the objects for imported classes
 */



const NotFound = () => {

    return (
        <div data-testid="not_found_page" className="not_found_text" >
            Custom - Page has not been found
        </div>
    );
}

export { NotFound }
