/**
    @CreatedBy        : Aswin Joseph Raj S
    @CreatedTime      : Oct 17 2022
    @ModifiedBy       : Dinesh
    @ModifiedTime     : Dec 07 2022
    @Description      : This file contain table component for DMS
**/


/**
 * Importing all the required modules 
 */
import { Spin } from "antd";
import React from "react";
import InfiniteScroll from "react-infinite-scroll-component";

/**
 * Initializing the objects for imported classes
 */

interface TableInterface {
    configs: {
        headerSettings: any
        tableName: string
        hasMoreRecords: boolean
        isHoverable: boolean
        isStriped: boolean
        isDark: boolean
        isBordered: boolean
    }
    data: Array<Object>
    callbacks: {
        handleOnClick: Function
        handleTableScroll: Function
    }
}

function Table(props: TableInterface) {
    return (
        <div style={{ maxHeight: "75vh", overflow: "auto" }} id="scrollableDiv">
            <InfiniteScroll
                dataLength={props?.data?.length}
                scrollableTarget="scrollableDiv"
                next={() => {
                    props?.callbacks.handleTableScroll
                }}
                hasMore={props?.configs.hasMoreRecords}
                scrollThreshold={500} //window.innerHeight > 750 ? 0.5 : 0.8
                data-testid={`base_web_components_common_table_${props?.configs.tableName}_container`}
                loader={
                    <div className="text-center mb-2">
                        <Spin data-testid={`base_web_components_common_table_${props?.configs.tableName}_spinner`} />
                    </div>
                }>
                <table
                    className={
                        `table 
                        ${props?.configs.isBordered ? "table-bordered" : "table-borderless"} 
                        ${props?.configs.isHoverable && "table-hover"} 
                        ${props?.configs.isStriped && "table-striped"} 
                        ${props?.configs.isDark && "table-dark"} 
                        sticky-table-headers`
                    }
                    data-testid={`base_web_components_common_table_${props?.configs.tableName}_table`}
                >
                    <thead data-testid={`base_web_components_common_table_${props?.configs.tableName}_tableheader`}>
                        <tr className="sticky-table-headers__sticky" data-testid={`base_web_components_common_table_${props?.configs.tableName}_tableheader_headerrow`}>
                            {props?.configs.headerSettings.map((headerSetting: any, index: any) => (
                                <th data-testid={`base_web_components_common_table_${props?.configs.tableName}_tableheader_${headerSetting.title}_column`} key={index}>{headerSetting.title}</th>
                            ))}
                        </tr>
                    </thead>

                    <tbody id="scrollableDiv" data-testid={`base_web_components_common_table_${props?.configs.tableName}_tablebody`}>
                        {props?.data.map((item: any, index: any) => (
                            <tr key={index}>
                                {props?.configs.headerSettings.map((headerSetting: any, index: any) => (
                                    <td
                                        key={index}
                                        style={{ maxWidth: `${headerSetting.width}` }}
                                        className="text-truncate"
                                        data-toggle="tooltip"
                                        data-placement="bottom"
                                        title={`${headerSetting?.render(item).props.children}`}
                                        onClick={() =>
                                            props.callbacks.handleOnClick(item)
                                        } >

                                        {headerSetting.render(item)}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>

                </table>
            </InfiniteScroll>
        </div>
    );
}

export { Table };
