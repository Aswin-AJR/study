/**
    @CreatedBy        : Aswin Joseph Raj S
    @CreatedTime      : Jan 10 2023 
    @ModifiedBy       : Aswin Joseph Raj s
    @ModifiedTime     : Jan 10 2023
    @Description      : This file contain date picker component for DMS
**/

import flatpickr from "flatpickr"
import { useContext, useEffect, useRef } from "react"
import "flatpickr/dist/themes/light.css";
import { LocaleSettingsContext } from "../../pages/_app";

/**
 * Importing all the required modules 
 */

interface DatePickerInterface {
    configs: {
        placeholder?: string
        showDate: boolean
        showTime: boolean
    }
    data: {
        value: string
    }
    callbacks: {
        handelSelectedDate: Function
    }
}

interface LocaleSettingsInterface {
    DisplayDateFormat: string
    DisplayTimeZone: string
    StoredDateFormat: string
    StoredTimeZone: string
    DateFieldFormat: string
    TimeFieldFormat: string
    StoredCurrencyFormat: string
    DisplayCurrencyFormat: string
}

function DatePicker(props: DatePickerInterface) {
    const localeSettings: LocaleSettingsInterface = useContext<any>(LocaleSettingsContext);
    const inputElement = useRef<any>(null);

    useEffect(() => {
        flatpickr(inputElement?.current, {
            dateFormat: `${props?.configs?.showDate ? localeSettings?.DateFieldFormat : ""} ${props?.configs?.showTime ? localeSettings?.TimeFieldFormat : ""}`,
            altFormat: `${props?.configs?.showDate ? localeSettings?.DateFieldFormat : ""} ${props?.configs?.showTime ? localeSettings?.TimeFieldFormat : ""}`,
            enableTime: props?.configs?.showTime,
            noCalendar: !props?.configs?.showDate,
            altInput: true,
            allowInput: true,
            onChange: (data: any) => props?.callbacks.handelSelectedDate(data[0]),
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <input
            ref={inputElement}
            id="date-time-picker"
            type="text"
            placeholder={props?.configs?.placeholder}
            defaultValue={props?.data?.value}
        />
    )
}
export { DatePicker }




