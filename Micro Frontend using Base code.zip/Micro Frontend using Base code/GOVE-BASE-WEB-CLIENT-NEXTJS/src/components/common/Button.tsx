import React from 'react'
import { Button as PrimeReactButton } from 'primereact/button';
import styled, { useTheme } from 'styled-components'
const PrimeButton = styled(PrimeReactButton)`
    background-color: ${(props: any) => props?.theme?.AppPrimaryColor || '#1f1044'}
`

interface ButtonInterface {
    configs: {
        buttonClassName?: string
        icon?: string
        buttonType?: string
    }
    data: {
        buttonLabel: string
    }
    callbacks: {
        handleButtonClick: Function
    }
}

function Button(props: ButtonInterface) {

    const theme = useTheme()

    return (
        <>
            {(props?.data?.buttonLabel?.length !== 0 || props?.configs?.icon?.length !== 0) &&
                <PrimeButton
                    theme={theme}
                    label={props?.data?.buttonLabel}
                    className={`p-button-sm ${props?.configs?.buttonClassName}`}
                    onClick={() => props?.callbacks?.handleButtonClick()}
                    icon={props?.configs?.icon}
                    type={props?.configs?.buttonType ? props?.configs?.buttonType : 'button'}
                    data-testid={`base_web_components_common_button_${props?.data?.buttonLabel}`}
                />
            }
        </>
    )
}

export { Button }