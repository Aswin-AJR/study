import React, { useEffect, useState } from 'react'
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import styled, { useTheme } from 'styled-components'

const PrimeButton = styled(Button)`
    background-color: ${(props: any) => props?.theme?.AppPrimaryColor || '#1f1044'}`

interface SearchBarInterface {
    configs: {
        placeholder: string
        onInputSearchEnabled?: boolean
    }
    data: {
        defaultValue?: string
    }
    callbacks: {
        handleSearch: Function
    }
}

function SearchBar(props: SearchBarInterface) {

    const theme = useTheme()
    const [searchKeyword, setSearchKeyword] = useState<string>('')

    const handleSearchBarInput = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSearchKeyword(event.target.value)
    }

    const handleSearchBarEnterKey = (event: React.KeyboardEvent<HTMLInputElement>) => {
        if (event?.keyCode === 13) {
            returnSearchBarKeyword()
        }
    }

    const returnSearchBarKeyword = () => {
        if (searchKeyword.trim().length !== 0) {
            props.callbacks.handleSearch(searchKeyword)
        }
    }

    useEffect(() => {
        props?.configs?.onInputSearchEnabled && returnSearchBarKeyword()
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [searchKeyword]);

    useEffect(() => {
        props?.data?.defaultValue && setSearchKeyword(props?.data?.defaultValue)
    }, [props?.data?.defaultValue]);

    return (
        <div className="p-inputgroup">
            <InputText
                type="text"
                name={"searchbar"}
                value={searchKeyword}
                placeholder={props?.configs?.placeholder}
                onChange={(e) => handleSearchBarInput(e)}
                onKeyUp={handleSearchBarEnterKey}
                data-testid={`base_web_components_common_searchbar_inputbox`}
            />
            <PrimeButton
                theme={theme}
                icon="pi pi-search"
                onClick={() => returnSearchBarKeyword()}
                data-testid={`base_web_components_common_searchbar_searchbutton`}
            />
        </div>
    )
}

export { SearchBar }