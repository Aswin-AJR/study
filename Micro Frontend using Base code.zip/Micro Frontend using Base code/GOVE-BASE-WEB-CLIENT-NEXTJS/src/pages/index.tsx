/**
* CreatedBy        : Dinesh
* CreatedTime      : 03 Dec 2022
* ModifiedBy       : Dinesh
* ModifiedTime     : 03 Dec 2022
* Description      : This file is index page
**/


/**
 * Importing all modules required
 */
import React, { useEffect } from 'react'
import { IndexConfig } from '../configs/pages/IndexConfig';
import { withPageMountDetection } from '../utils/hoc/withPageMountDetection';
import { useLogger } from '../utils/hooks/useLogger';

const indexConfig = new IndexConfig()

function Index() {
   

    return (
        <div data-testid="base_web_pages_index_container">Home Page</div>
    )
}

export default withPageMountDetection(Index, indexConfig.INDEX_PAGE_DEFAULT_CONFIG, { logger: useLogger }) 