/**
* CreatedBy        : Karthick
* CreatedTime      : 20 Dec 2022
* ModifiedBy       : Karthick
* ModifiedTime     : 20 Dec 2022
* Description      : This file is index page for Signin module
**/


/**
 * Importing all modules required
 */
import React from 'react'

function SignInIndex() {
    return (
        <div data-testid='base_web_pages_signin_signinindex'>Login Page</div>
    )
}

export default SignInIndex