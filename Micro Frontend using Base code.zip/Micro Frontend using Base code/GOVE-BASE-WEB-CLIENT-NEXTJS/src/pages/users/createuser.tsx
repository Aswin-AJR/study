/**
* CreatedBy        : Dinesh
* CreatedTime      : 03 Dec 2022
* ModifiedBy       : Dinesh
* ModifiedTime     : 03 Dec 2022
* Description      : This file is index page for Create User module
**/


/**
 * Importing all modules required
 */
import React from 'react'
import { AppConfig } from '../../configs/pages/AppConfig';
import { CreateUserConfig } from '../../configs/pages/users/CreateUserConfig';
import { HelperFunction } from '../../utils/HelperFunction';
import { withPageMountDetection } from '../../utils/hoc/withPageMountDetection';
import { useLogger } from '../../utils/hooks/useLogger';

const createUserConfig = new CreateUserConfig()
const appConfig = new AppConfig()
const helperFunction = new HelperFunction()

function CreateUser() {
    return (
        <div data-testid="base_web_pages_users_createuser_container">CreateUser</div>
    )
}

export default withPageMountDetection(CreateUser, createUserConfig.CREATE_USER_PAGE_DEFAULT_CONFIG, { logger: useLogger })

export async function getServerSideProps(context: any) {
    if (helperFunction.isURLRestricted(appConfig.USER_RESTRICTED_ROUTES, context.resolvedUrl)) {
        return {
            redirect: {
                destination: "/",
                permanent: false,
            },
            props: {},
        };
    } else {
        return {
            props: {},
        };
    }
}