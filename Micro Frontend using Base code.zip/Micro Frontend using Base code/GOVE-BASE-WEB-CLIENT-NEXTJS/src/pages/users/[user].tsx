/**
@CreatedBy        : Dinesh
@CreatedTime      : Nov 17 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Nov 17 2022
@Description      : This file default base page
**/

/**
 * Importing all the classes and modules
 */
import React from 'react'
import { useRouter } from "next/router";
import { UserDetailConfig } from "../../configs/pages/users/UserDetailConfig";
import { useLogger } from "../../utils/hooks/useLogger";
import { withPageMountDetection } from '../../utils/hoc/withPageMountDetection';

/**
 * Initializing the objects for imported classes
 */
const userDetailConfig = new UserDetailConfig()


const UserDetail = () => {

    let router = useRouter()

    return (
        <div data-testid="base_web_pages_userdetail_container" className="index_text" >
            USER-ID :{JSON.stringify(router.query)}
        </div>
    );
}

export default withPageMountDetection(UserDetail, userDetailConfig.USER_DETAIL_PAGE_DEFAULT_CONFIG, { logger: useLogger }) 