/**
* CreatedBy        : Dinesh
* CreatedTime      : 03 Dec 2022
* ModifiedBy       : Dinesh
* ModifiedTime     : 03 Dec 2022
* Description      : This file is index page for Edit User module
**/


/**
 * Importing all modules required
 */
import React from 'react'
import { EditUserConfig } from '../../configs/pages/users/EditUserConfig';
import { withPageMountDetection } from '../../utils/hoc/withPageMountDetection';
import { useLogger } from '../../utils/hooks/useLogger';

const editUserConfig = new EditUserConfig()

function EditUser() {
    return (
        <div data-testid="base_web_pages_users_edituser_container">EditUser</div>
    )
}

export default withPageMountDetection(EditUser, editUserConfig.EDIT_USER_PAGE_DEFAULT_CONFIG, { logger: useLogger }) 