/**
* CreatedBy        : Dinesh
* CreatedTime      : 03 Dec 2022
* ModifiedBy       : Dinesh
* ModifiedTime     : 03 Dec 2022
* Description      : This file is index page for user module
**/


/**
 * Importing all modules required
 */
import React, { useEffect, useState } from "react"

/**
 * Importing all components needed in this page
 */
import { UserIndexTopZone } from "../../zones/users/userindex/UserIndexTopZone";
import { UserIndexBottomZone } from "../../zones/users/userindex/UserIndexBottomZone";
import { PrivateRoute } from "../../router/PrivateRoute";
import { useLogger } from "../../utils/hooks/useLogger";
import { UserIndexConfig } from "../../configs/pages/users/UserIndexConfig";
import { withPageMountDetection } from "../../utils/hoc/withPageMountDetection";
import FeatureAvailabilityFlag from '../../../feature.config.json'
import { UserIndexFunction } from "../../functions/users/UserIndexFunction";

/**
 * Initializing the objects for imported classes
 */
const userIndexConfig = new UserIndexConfig()
let userIndexFunction = new UserIndexFunction()

const UserIndex = (props: any) => {
    console.info("GET STATIC PROPS ---->>>>", props?.sample)

    const [userList, setUserList] = useState<any>([])

    useEffect(() => {
        const asyncUseEffectFunction = async () => {
            setUserList(await userIndexFunction.ReadUserByFilter({}, {}, 10, 0, {}))
        }
        asyncUseEffectFunction()
    }, []);

    return (
        <PrivateRoute>
            <div data-testid={`base_web_pages_users_userindex`} className="user_index_page_class">
                <UserIndexTopZone
                    configs={{
                        features: {
                            isCreateUserFeatureActive: FeatureAvailabilityFlag["base.web.feature.users"]["base.web.feature.users.createuser"].isFeatureActive,
                            isSearchUserFeatureActive: FeatureAvailabilityFlag["base.web.feature.users"]["base.web.feature.users.searchusers"].isFeatureActive
                        },
                        languageConfig: userIndexConfig.USER_INDEX_PAGE_LANGUAGE_CONFIG.userIndexTopZone_lang_config
                    }}
                    data={{}}
                    callbacks={{}}
                />
                <UserIndexBottomZone
                    configs={{
                        features: {
                            isListUsersFeatureActive: FeatureAvailabilityFlag["base.web.feature.users"]["base.web.feature.users.listusers"].isFeatureActive
                        },
                        languageConfig: userIndexConfig.USER_INDEX_PAGE_LANGUAGE_CONFIG.userIndexBottomZone_lang_config
                    }}
                    data={{
                        userList: userList
                    }}
                    callbacks={{}}
                />
            </div>
        </PrivateRoute>
    );
}

export default withPageMountDetection(UserIndex, userIndexConfig.USER_INDEX_PAGE_DEFAULT_CONFIG, { logger: useLogger })

// USE THIS FUNCTION WHEN THE DATA CHANGES INCREMENTALLY - CONFIG THE REVALIDATION DURATION
export async function getStaticProps() {
    const res = await fetch('https://jokeapi.dev/joke/programming/random')
    const sample = await res.json()

    return {
        props: {
            sample,
        },
        revalidate: 10 // In seconds
    }
}
