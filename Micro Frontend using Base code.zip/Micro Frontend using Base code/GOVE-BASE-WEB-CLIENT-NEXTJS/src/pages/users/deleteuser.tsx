/**
* CreatedBy        : Dinesh
* CreatedTime      : 03 Dec 2022
* ModifiedBy       : Dinesh
* ModifiedTime     : 03 Dec 2022
* Description      : This file is index page for Delete User module
**/


/**
 * Importing all modules required
 */
import React from 'react'
import { DeleteUserConfig } from '../../configs/pages/users/DeleteUserConfig';
import { withPageMountDetection } from '../../utils/hoc/withPageMountDetection';
import { useLogger } from '../../utils/hooks/useLogger';

const deleteUserConfig = new DeleteUserConfig()

function DeleteUser() {
    return (
        <div data-testid="base_web_pages_users_deleteuser_container">DeleteUser</div>
    )
}

export default withPageMountDetection(DeleteUser, deleteUserConfig.DELETE_USER_PAGE_DEFAULT_CONFIG, { logger: useLogger }) 