/**
* CreatedBy        : Karthick
* CreatedTime      : 20 Dec 2022
* ModifiedBy       : Karthick
* ModifiedTime     : 20 Dec 2022
* Description      : This file is index page for Signup module
**/


/**
 * Importing all modules required
 */
import React from 'react'

function SignUpIndex() {
    return (
        <div>SignUpIndex</div>
    )
}

export default SignUpIndex