/**
@CreatedBy        : Karthick DK
@CreatedTime      : Nov 17 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 08 2022
@Description      : This file is the entry point for application
**/

/**
 * Importing custom css from styles folder
 */
import "../styles/globals.scss";

/**
 * Importing custom css for pages 
 */
import "../styles/pages/IndexStyle.scss";
import '../styles/pages/UserStyle.scss';

/**
 * Importing custom css for components
 */
import "../styles/components/MainStyle.scss";
import "../styles/components/common/FooterStyle.scss";
import "../styles/components/common/TopbarStyle.scss";
import "../styles/components/common/SidebarStyle.scss"


/**
 * Importing pre-built css modules
 */
import "bootstrap/dist/css/bootstrap.min.css";
import "primereact/resources/themes/lara-light-indigo/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";
import "material-icons/iconfont/material-icons.css";

/**
 * Importing required modules
 */
import React, { useEffect, useState } from "react";
import type { AppProps } from "next/app";
import { ProSidebarProvider } from 'react-pro-sidebar';
import { Auth } from "../utils/Auth";
import { AppLayout } from "../layout/AppLayout";
import { ThemeProvider } from 'styled-components'
import _ from 'lodash'
import { ThemeConfig } from "../configs/theme/ThemeConfig";
import { UserAuthContextProvider } from "../utils/context/UserAuthContextProvider"
import { AppConfig } from "../configs/pages/AppConfig";
import localeSettings from '../../locale.settings.json'
import Router, { useRouter } from "next/router";
import { Locale } from "../utils/Locale";
import { HelperFunction } from "../utils/HelperFunction"
import { ProgressSpinner } from 'primereact/progressspinner';
import '@module-federation/nextjs-mf/src/include-defaults'; 


/**
 * Initializing the objects for imported classes
 */
let auth = new Auth()
let defaultThemeConfig = new ThemeConfig()
let appConfig = new AppConfig()

export const UserSettingsContext = React.createContext({});
export const LocaleSettingsContext = React.createContext({});
export const UtilityContext = React.createContext({});

export default function App({ Component, pageProps }: AppProps) {

    const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false)
    const [isLoading, setLoading] = useState<boolean>(true)
    const [isPageLoading, setIsPageLoading] = useState<boolean>(false)
    const [userSettings, setUserSettings] = useState<any>({})
    const router = useRouter();

    const [utility, setUtility] = useState<any>({})

    // After SSO is successful user email id should be provided (COMES FROM SSO SERVICE)
    let loggedInUserEmail = "dinesh@alitasys.com"

    const handlePageLoadingStart = () => {
        setIsPageLoading(true);
    };
    const handlePageLoadingEnd = () => {
        setIsPageLoading(false);
    };

    useEffect(() => {
        Router.events.on("routeChangeStart", handlePageLoadingStart);
        Router.events.on("routeChangeComplete", handlePageLoadingEnd);
        Router.events.on("routeChangeError", handlePageLoadingEnd);

        // Check if user exists in the auth mangement system
        auth.getUserByEmailID(loggedInUserEmail).then(async (authenticatedUserObject) => {
            if (authenticatedUserObject == null) {
                setIsAuthenticated(false)
                setLoading(false)
            } else {
                let userSettings = auth.getUserAuthSettings()
                let locale = await Locale.initialize(userSettings?.LocaleSettings)
                setUtility({
                    locale: locale,
                    helperFunction: new HelperFunction()
                })
                setUserSettings(userSettings)
                setIsAuthenticated(true)
                setLoading(false)
            }
        })
        return () => {
            Router.events.off("routeChangeStart", handlePageLoadingStart);
            Router.events.off("routeChangeComplete", handlePageLoadingEnd);
            Router.events.off("routeChangeError", handlePageLoadingEnd);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    return (
        <>
            {isLoading ?
                <>Loading...</> :
                <UserAuthContextProvider value={isAuthenticated}>
                    <ProSidebarProvider>
                        <UtilityContext.Provider value={utility}>
                            <LocaleSettingsContext.Provider value={!_.isEmpty(userSettings?.LocaleSettings) ? userSettings?.LocaleSettings : localeSettings}>
                                <UserSettingsContext.Provider value={userSettings}>
                                    <ThemeProvider theme={!_.isEmpty(userSettings?.ThemeSetting) ? userSettings?.ThemeSetting : defaultThemeConfig.THEME_CONFIG}>
                                        {appConfig.PUBLIC_ROUTES_WITHOUT_PRIVATE_APP_LAYOUT.includes(router.pathname) ?
                                            <>
                                                {isPageLoading ?
                                                    <ProgressSpinner style={{width: '50px', height: '50px'}} strokeWidth="8" fill="var(--surface-ground)" animationDuration=".5s"/> :
                                                    <Component {...pageProps} />
                                                }
                                            </> :
                                            <AppLayout>
                                                {/* USED IF NEXT JS DEFAULT FILE SYSTEM PUBLIC ROUTES IS ENABLED */}
                                                <>
                                                    {isPageLoading ?
                                                        <ProgressSpinner className="text-center" style={{width: '50px', height: '50px'}} strokeWidth="8" fill="var(--surface-ground)" animationDuration=".5s"/> :
                                                        <Component {...pageProps} />
                                                    }
                                                </>
                                            </AppLayout>
                                        }
                                    </ThemeProvider>
                                </UserSettingsContext.Provider>
                            </LocaleSettingsContext.Provider>
                        </UtilityContext.Provider>
                    </ProSidebarProvider>
                </UserAuthContextProvider>
            }
        </>
    );
}
