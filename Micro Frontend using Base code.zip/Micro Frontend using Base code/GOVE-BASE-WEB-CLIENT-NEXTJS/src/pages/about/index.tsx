/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 12 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : DEc 12 2022
@Description      : This file is the default view to render when there is no match found
**/

/**
 * Importing all the classes and modules
 */
import React from 'react'

/**
 * Initializing the objects for imported classes
 */


function AboutIndex(){

    return (
        <div data-testid="base_web_pages_about_index">
            About Us
        </div>
    );
}

export default AboutIndex
