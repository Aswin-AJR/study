/**
* CreatedBy        : Karthick
* CreatedTime      : Jan 02 2022
* ModifiedBy       : Karthick
* ModifiedTime     : Jan 02 2022
* Description      : This file contains all the api's for user index page 
**/

import UserMock from "../../mocks/UserMock.json"
// import axios from "axios"
// import { AxiosHttpService } from "../../utils/restclient/AxiosHttpService"
// import { RestClient } from "../../utils/restclient/RestClient"

// const axiosClient = new AxiosHttpService(axios)
// const restClient = new RestClient(axiosClient)

export class UserIndexApi {
    async ReadUserByFilter(filter: Object, fields: Object, limit: Number, page: Number, sort: Object) {
        console.info("ReadUserByFilter Function Input", filter, fields, limit, page, sort)
        let output: any = UserMock
        return output
    }
}