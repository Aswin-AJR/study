/**
* CreatedBy        :Vasanth Varatharajan
* CreatedTime      : 02 Jan 2023
* ModifiedBy       :Vasanth Varatharajan
* ModifiedTime     : 02 Jan 2023
* Description      : This file contains interfaces for uselogger in hooks   
**/

export interface UserSessionLogInterface {
    SessionKey?: string,
    AppInfo?: {
        ApplicationKey: string,
        ApplicationInstanceKey: string,
        ApplicationName: string
    },
    UserInfo?: {
        UserKey: string,
        UserName: string
    },
    DeviceInfo: {
        DeviceOS: string,
        DeviceType: string,
        IpAddress: string,
        MacAddress: string,
        DeviceLocation: string,
        DeviceLatitude: string,
        DeviceLongitude: string
    },
    SessionStartTime?: string,
    SessionEndTime?: string
}

export interface UserActivityLogInterface {
    SessionKey?: string,
    LayerInfo?: {
        LayerName: string,
        LayerHost: string,
        LayerPort: string
    }
    MerchantInfo?: {
        MerchantKey: string,
        MerchantName: string
    }
    TenantInfo?: {
        TenantKey: string,
        TenantName: string
    },
    UserInfo?: {
        UserKey: string,
        UserName: string
    },
    PageID: string,
    PageName: string,
    PageRoute: string,
    PageEnteredTime: string,
    PageSpentTime?: string,
    PageLeftTime: string,
    CreatedTime?: string,
    IsArchived?: boolean,
    ArchivedUserKey?: string | null,
    ArchivedBy?: string | null,
    ArchivedTime?: string | null
}

