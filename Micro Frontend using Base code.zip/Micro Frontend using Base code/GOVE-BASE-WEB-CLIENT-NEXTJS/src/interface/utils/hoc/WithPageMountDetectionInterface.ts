/**
* CreatedBy        :Vasanth Varatharajan
* CreatedTime      : 02 Jan 2023
* ModifiedBy       :Vasanth Varatharajan
* ModifiedTime     : 02 Jan 2023
* Description      : This file contains interfaces for withpagemountdetection in hoc   
**/

export interface UserActivityLogInterface {
    PageID: string
    PageName: string
    PageRoute: string
    PageEnteredTime: string
    PageLeftTime: string
}

export interface PageConfigInterface {
    PageID: string
    PageName: string
    PageRoute: string
}

export interface withMountDetectionCallbacksInterface {
    logger: Function
}