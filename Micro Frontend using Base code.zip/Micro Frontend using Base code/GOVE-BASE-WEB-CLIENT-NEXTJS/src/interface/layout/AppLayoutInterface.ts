/**
* CreatedBy        :Vasanth Varatharajan
* CreatedTime      : 02 Jan 2023
* ModifiedBy       :Vasanth Varatharajan
* ModifiedTime     : 02 Jan 2023
* Description      : This file contains interfaces for  app layout  
**/



/**
 * This interface defines properties of theme
 */

export interface AppLayoutInterface {
    children?: JSX.Element;
}


export interface UserSettingsInterface {
    "AuthKey": string,
    "User": {
        "UserKey": string,
        "UserName": string,
        "UserEmail": string,
        "UserType": string,
        "UserRole": string
    },
    "Merchant": {
        "MerchantKey": string,
        "MerchantName": string,
        "MerchantLogoURL": string
    },
    "Tenant": [
        {
            "TenantKey": string,
            "TenantName": string,
            "TenantLogoURL": string
        },
        {
            "TenantKey": string,
            "TenantName": string,
            "TenantLogoURL": string
        }
    ],
    "InstanceSettings": {
        "EnvironmentName": string
    },
    "ThemeSetting": {
        "ThemeName": string,
        "FontFamily": string,
        "TopbarBackgroundColor": string,
        "TopbarFontColor": string,
        "SidebarBackgroundColor": string,
        "SidebarFontColor": string,
        "BodyBackgroundColor": string,
        "BodyFontColor": string,
        "FooterBackgroundColor": string,
        "FooterFontColor": string
    },
    "SidebarSettings": object
}
