F/**
* CreatedBy        :Vasanth Varatharajan
* CreatedTime      : 02 Jan 2023
* ModifiedBy       :Vasanth Varatharajan
* ModifiedTime     : 02 Jan 2023
* Description      : This file contains interfaces for  topbar in layout  
**/


/**
 * This interface defines properties of topbar
 */

export interface AppDefaultConfigInterface {
    appName: string
    appLogo: string
    appTheme: any
}

export interface SidebarDefaultConfigInterface {
    isSidebarVisible: boolean
}

export interface TopbarMenusInterface {
    menuName: string,
    menuDisplayName: string,
    menuKey: number,
    menuPath: string,
    menuIcon: object,
    subMenus: Array<TopbarMenusInterface> | undefined,
    isDividerVisibleAtBottom?: boolean,
    isMenuEnabled: boolean,
    isMenuVisible: boolean
}
export interface TopbarDefaultConfigInterface {
    topbarMenuConfig: Array<TopbarMenusInterface>
    topbarAppLogoWidth: number
    topbarAppLogoHeight: number
}

export interface TenantListInterface {
    TenantKey: string,
    TenantName: string,
    TenantLogoURL: string
}

export interface MerchantInfoInterface {
    MerchantKey: string,
    MerchantName: string,
    MerchantLogoURL: string
}

export interface UserInfoInterface {
    UserKey: string,
    UserName: string,
    UserEmail: string,
    UserType: string,
    UserRole: string
}
export interface InstanceInfoInterface {
    EnvironmentName: string
}
export interface TopbarInterface {
    configs: {
        sideBarConfig: SidebarDefaultConfigInterface,
        appConfig: AppDefaultConfigInterface,
        topbarConfig: TopbarDefaultConfigInterface
    }
    data: {
        tenantList: Array<TenantListInterface>
        merchantInfo: MerchantInfoInterface
        userInfo: UserInfoInterface
        instanceInfo: InstanceInfoInterface
    }
    callbacks: any
}