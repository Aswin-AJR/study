/**
* CreatedBy        :Vasanth Varatharajan
* CreatedTime      : 02 Jan 2023
* ModifiedBy       :Vasanth Varatharajan
* ModifiedTime     : 02 Jan 2023
* Description      : This file contains interfaces for  footer layout  
**/


/**
 * This interface defines properties of footer
 */

export interface footerConfigInterface {
    footerText: String
}

export interface FooterInterface {
    children: {
        configs: {
            footerConfig: footerConfigInterface
            appConfig: {
                appTheme: any
            },
        }
        data: any
        callbacks: any
    }
}