/**
* CreatedBy        :Vasanth Varatharajan
* CreatedTime      : 02 Jan 2023
* ModifiedBy       :Vasanth Varatharajan
* ModifiedTime     : 02 Jan 2023
* Description      : This file contains interfaces for  sidebar in layout  
**/

export interface AppDefaultConfigInterface {
    appName: string
    appLogo: string
    appTheme: any
}

export interface SidebarMenusInterface {
    menuName: string,
    menuDisplayName: string,
    menuKey: number,
    menuPath: string,
    menuIcon: object,
    subMenus: Array<SidebarMenusInterface> | undefined,
    isMenuEnabled: boolean,
}

export interface SidebarDefaultConfigInterface {
    sidebarMenuConfig: Array<SidebarMenusInterface>
    sidebarAppLogoWidth?: number
    sidebarAppLogoHeight?: number
    sidebarBackgroundColor?: string
    sidebarFontColor?: string
}
export interface SidebarInterface {
    children: {
        configs: {
            sideBarConfig: SidebarDefaultConfigInterface
            appConfig: AppDefaultConfigInterface
        }
        data: {}
        callbacks: any
    }
}
