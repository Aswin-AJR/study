/**
* CreatedBy        :Vasanth Varatharajan
* CreatedTime      : 02 Jan 2023
* ModifiedBy       :Vasanth Varatharajan
* ModifiedTime     : 02 Jan 2023
* Description      : This file contains interfaces for useridexbottomzone in zones   
**/


export interface UserIndexBottomZoneInterface {
    configs: {
        features: {
            isListUsersFeatureActive: boolean
        },
        languageConfig: any
    }
    data: {
        userList: any
    }
    callbacks: any
}