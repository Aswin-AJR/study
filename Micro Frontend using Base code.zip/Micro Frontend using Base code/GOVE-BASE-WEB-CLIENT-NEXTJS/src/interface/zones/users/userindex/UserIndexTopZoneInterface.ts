/**
* CreatedBy        :Vasanth Varatharajan
* CreatedTime      : 02 Jan 2023
* ModifiedBy       :Vasanth Varatharajan
* ModifiedTime     : 02 Jan 2023
* Description      : This file contains interfaces for useridextopzone in zones   
**/


export interface UserIndexTopZoneInterface {
    configs: {
        features: {
            isSearchUserFeatureActive: boolean
            isCreateUserFeatureActive: boolean
        },
        languageConfig: any
    }
    data: {}
    callbacks: any
}