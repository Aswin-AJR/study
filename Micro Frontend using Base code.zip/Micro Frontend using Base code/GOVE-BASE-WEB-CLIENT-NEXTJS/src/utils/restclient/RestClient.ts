import { AxiosBasicCredentials } from "axios";
/* eslint-disable no-unused-vars */
interface HttpService {
    get(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    post(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    put(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    delete(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
}

export class RestClient {
    private restClient: HttpService;

    constructor(restClient: HttpService) {
        this.restClient = restClient;
    }

    async get(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        return await this.restClient.get(url, headers, {
            username: auth.username,
            password: auth.password
        })
    }

    async post(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        return await this.restClient.post(url, data, headers, {
            username: auth.username,
            password: auth.password
        })
    }

    async put(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        return await this.restClient.put(url, data, headers, {
            username: auth.username,
            password: auth.password
        })
    }

    async delete(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        return await this.restClient.delete(url, headers, {
            username: auth.username,
            password: auth.password
        })
    }
}