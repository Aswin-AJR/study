/* eslint-disable no-unused-vars */
import { AxiosBasicCredentials } from 'axios';

interface HttpService {
    get(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    post(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    put(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    delete(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
}

export class FetchHttpService implements HttpService {

    private generateResponse(response: Response) {
        return new Promise((resolve, reject) => {
            if (response.ok) {
                response.json().then(data => {
                    resolve({
                        status: response.status,
                        message: response.statusText,
                        output: data,
                    });
                });
            } else {
                reject(response.statusText);
            }
        });
    }

    async get(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        const options: RequestInit = { headers };
        if (auth) {
            options.headers = { ...options.headers, Authorization: `Basic ${Buffer.from(`${auth.username}:${auth.password}`).toString('base64')}` };
        }
        const response = await fetch(url, options);
        return await this.generateResponse(response);
    }

    async post(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        const options: RequestInit = {
            method: 'POST',
            body: JSON.stringify(data),
            headers: { ...headers, 'Content-Type': 'application/json' },
        };
        if (auth) {
            options.headers = { ...options.headers, Authorization: `Basic ${Buffer.from(`${auth.username}:${auth.password}`).toString('base64')}` };
        }
        const response = await fetch(url, options);
        return await this.generateResponse(response);
    }

    async put(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        const options: RequestInit = {
            method: 'PUT',
            body: JSON.stringify(data),
            headers: { ...headers, 'Content-Type': 'application/json' },
        };
        if (auth) {
            options.headers = { ...options.headers, Authorization: `Basic ${Buffer.from(`${auth.username}:${auth.password}`).toString('base64')}` };
        }
        const response = await fetch(url, options);
        return await this.generateResponse(response);
    }

    async delete(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        const options: RequestInit = { method: 'DELETE', headers };
        if (auth) {
            options.headers = { ...options.headers, Authorization: `Basic ${Buffer.from(`${auth.username}:${auth.password}`).toString('base64')}` };
        }
        const response = await fetch(url, options);
        return await this.generateResponse(response);
    }
}
