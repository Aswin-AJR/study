/* eslint-disable no-unused-vars */
import { AxiosInstance, AxiosBasicCredentials, AxiosResponse } from 'axios';
import { Response } from 'node-fetch';

// This is the interface for the service that will handle the HTTP requests
interface HttpService {
    get(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    post(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    put(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
    delete(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any>;
}

// The AxiosHttpService class implements the HttpService interface using axios
export class AxiosHttpService implements HttpService {
    constructor(private axios: AxiosInstance) { }

    private generateResponse(response: AxiosResponse) {
        return {
            status: response.status,
            message: response.statusText,
            output: response.data,
        };
    }

    async get(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        let response = await this.axios.get(url, { headers, auth })
        return this.generateResponse(response)
    }

    async post(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        let response = await this.axios.post(url, data, { headers, auth })
        return this.generateResponse(response)
    }

    async put(url: string, data: any, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        let response = await this.axios.put(url, data, { headers, auth })
        return this.generateResponse(response)
    }

    async delete(url: string, headers: Record<string, string>, auth: AxiosBasicCredentials): Promise<any> {
        let response = await this.axios.delete(url, { headers, auth })
        return this.generateResponse(response)
    }
}

