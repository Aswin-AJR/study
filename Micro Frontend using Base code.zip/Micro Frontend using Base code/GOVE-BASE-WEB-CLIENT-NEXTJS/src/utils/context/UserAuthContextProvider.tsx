/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 19 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Dec 19 2022
@Description      : This file contains context for user authentication
**/

/**
 * Importing required modules
 */
import React, { createContext, useContext, useState } from 'react';
import { UserAuthInterface } from '../../interface/utils/context/UserAuthContextProviderInterface'

/**
 * Initializing the objects for imported classes
 */
const UserAuthContext = createContext<UserAuthInterface | null>(null);

export function useAuth(): UserAuthInterface {
    const context = useContext(UserAuthContext);
    if (context === null) {
        return { isUserAuthenticated: false, setIsUserAuthenticated: () => { } };
    }
    return context;
}

export function UserAuthContextProvider(props: { children: React.ReactNode; value: boolean }) {
    const [isUserAuthenticated, setIsUserAuthenticated] = useState(props.value);
    return (
        <UserAuthContext.Provider value={{ isUserAuthenticated, setIsUserAuthenticated }}>
            {props.children}
        </UserAuthContext.Provider>
    );
}
