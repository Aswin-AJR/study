/**
@CreatedBy        : Karthick DK
@CreatedTime      : Dec 23 2022
@ModifiedBy       : Karthick DK
@ModifiedTime     : Dec 23 2022
@Description      : This file contains custom hook to handle all the logs
**/

import UserActivityMock from "../../mocks/UserActivityMock.json"
import { HelperFunction } from "../HelperFunction"
import {
    UserSessionLogInterface,
    UserActivityLogInterface
} from '../../interface/utils/hooks/UseloggerInterface'
import * as Logger from "@gove/logger"
import loggerConfig from "../../../logger.config.json"

const helperFunction = new HelperFunction()
const sessionLogger =  new Logger.WebclientSessionLogger(loggerConfig["webclient.session.config"])
const activityLogger = new Logger.WebclientActivityLogger(loggerConfig["webclient.activity.config"])
function useLogger() {

    const logMessage = (logMessage: string) => {
        console.info(logMessage);
    }

    const logUserActivity = (userActivityLog: UserActivityLogInterface) => {
        let userActivity = UserActivityMock
        userActivity.PageID = userActivityLog.PageID
        userActivity.PageName = userActivityLog.PageName
        userActivity.PageRoute = userActivityLog.PageRoute
        userActivity.PageEnteredTime = userActivityLog.PageEnteredTime.toString()
        userActivity.PageSpentTime = helperFunction.getTimeDifference(userActivityLog.PageEnteredTime, userActivityLog.PageLeftTime)
        userActivity.PageLeftTime = userActivityLog.PageLeftTime.toString()
        userActivity.CreatedTime = new Date().toISOString()
        console.info(userActivity);
        activityLogger.Info(userActivity)

    }

    const logSession = (userSession: UserSessionLogInterface) => {
        console.info(userSession);
        sessionLogger.Info(userSession)
    }

    return { logMessage, logUserActivity, logSession };
}

export { useLogger }