/**
@CreatedBy        : Aswin Joseph Raj S
@CreatedTime      : Jan 17 2023
@ModifiedBy       : Aswin Joseph Raj S
@ModifiedTime     : Jan 17 2023
@Description      : This file contains custom hook to transale
**/

interface useTranslateInterface {
    languageConfig: any,
    displayLanguage: string
}

function useTranslate(translationData: useTranslateInterface) {

    const translate = (string: string) => {
        if (translationData?.languageConfig[string]?.[translationData.displayLanguage]) {
            return translationData.languageConfig[string][translationData.displayLanguage]
        } else {
            return string
        }
    }
    return { translate };
}

export { useTranslate }

