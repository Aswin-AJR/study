/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contains all authentication operation
**/

import AuthUserMock from "../mocks/AuthUserMock.json"
import AuthUserSettings from "../mocks/AuthUserSettings.json"

class Auth {

    async getUserByEmailID(emailID: string) {
        if (AuthUserMock.UserEmail == emailID) {
            return AuthUserMock
        }
        else {
            return null
        }
    }

    getUserAuthSettings() {
        return AuthUserSettings
    }

}

export { Auth }
