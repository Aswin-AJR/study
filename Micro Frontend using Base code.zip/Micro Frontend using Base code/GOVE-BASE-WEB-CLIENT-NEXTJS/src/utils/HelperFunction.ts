/**
@CreatedBy        : Karthick D K
@CreatedTime      : Dec 23 2022
@ModifiedBy       : Karthick D K
@ModifiedTime     : Dec 23 2022
@Description      : This file contains all helper functions
**/

class HelperFunction {

    getTimeDifference(startDate: string, endDate: string): string {

        // Parse the ISO string dates into Date objects
        let start = new Date(startDate);
        let end = new Date(endDate);

        // Calculate the difference in milliseconds
        let diff = end.getTime() - start.getTime();

        // Calculate the number of seconds, minutes, and hours
        let sec = Math.floor(diff / 1000);
        let min = Math.floor(sec / 60);
        let hrs = Math.floor(min / 60);

        // Calculate the remainder seconds, minutes, and hours
        sec = sec % 60;
        min = min % 60;
        hrs = hrs % 24;

        // Format the time difference as a string in the format "hh:mm:ss"
        let timeDifference = `${hrs.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;

        return timeDifference;
    }

    isURLRestricted(restrictedURLs: Array<string | null>, url: string) {
        return restrictedURLs.includes(url);
    }

}

export { HelperFunction }
