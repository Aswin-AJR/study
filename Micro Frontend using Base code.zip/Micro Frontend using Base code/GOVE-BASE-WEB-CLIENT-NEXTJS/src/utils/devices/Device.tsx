/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contains all authentication operation
**/


class Auth {

    async getUserByEmailID(emailID : string){
        console.info(emailID)
    }

}

export {Auth}
