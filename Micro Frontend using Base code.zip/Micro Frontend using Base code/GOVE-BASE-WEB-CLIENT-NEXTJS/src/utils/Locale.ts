/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contains all locale related operations
**/

import moment from "moment-timezone";

interface LocaleSettingsInterface {
    DisplayDateFormat: string
    DisplayTimeZone: string
    StoredDateFormat: string
    StoredTimeZone: string
    DateFieldFormat: string
    TimeFieldFormat: string
    StoredCurrencyFormat: string
    DisplayCurrencyFormat: string
}

class Locale {

    exchangeRateInfo: any
    localeSettings: LocaleSettingsInterface
    private constructor(localeSettings: LocaleSettingsInterface, exchangeRateInfo: any) {
        this.exchangeRateInfo = exchangeRateInfo
        this.localeSettings = localeSettings
    }

    static async initialize(localeSettings: LocaleSettingsInterface) {
        try {
            const res = await fetch(`https://api.exchangerate-api.com/v4/latest/${localeSettings?.StoredCurrencyFormat}`)
            let exchangeRateInfo = await res.json()
            return new Locale(localeSettings, exchangeRateInfo);
        } catch (error) {
            console.error(error);
        }
    }

    async getExchangeRate(localeSettings: LocaleSettingsInterface) {
        try {
            const res = await fetch(`https://api.exchangerate-api.com/v4/latest/${localeSettings?.StoredCurrencyFormat}`)
            this.exchangeRateInfo = await res.json()
            console.info("1111")
        } catch (error) {
            console.error(error);
        }
    }

    getUserGeoLocation() {
        if (navigator?.geolocation) {
            navigator?.geolocation?.getCurrentPosition(function (position) {
                return position?.coords
            }, function (error) {
                return error
            });
        }
    }

    getDisplayDateTimeFormat(date: string) {
        const formattedDate = moment(date)?.tz(this.localeSettings?.DisplayTimeZone)?.format(this.localeSettings?.DisplayDateFormat);
        return formattedDate
    }

    convertDateTimeToStoredDateTimeFormat(date: string) {
        const formattedDate = moment(date)?.tz(this.localeSettings?.StoredTimeZone)?.format(this.localeSettings?.StoredDateFormat);
        return formattedDate
    }

    getDisplayCurrencyFormat(currency: any): string | number {
        const rate = this.exchangeRateInfo?.rates[this.localeSettings?.DisplayCurrencyFormat]
        const convertedValue = currency * rate
        const formatter = new Intl.NumberFormat(this.localeSettings?.DisplayCurrencyFormat, { style: 'currency', currency: this.localeSettings?.DisplayCurrencyFormat })
        const formattedValue = formatter?.format(convertedValue)
        return formattedValue
    }

}

export { Locale }
