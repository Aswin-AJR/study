/**
* CreatedBy        : Karthick
* CreatedTime      : Jan 02 2022
* ModifiedBy       : Karthick
* ModifiedTime     : Jan 02 2022
* Description      : This file contains all the endpoints for this application 
**/

export class Endpoints {

}