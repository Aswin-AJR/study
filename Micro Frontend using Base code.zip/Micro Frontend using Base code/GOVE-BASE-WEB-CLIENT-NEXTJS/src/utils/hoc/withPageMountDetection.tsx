import React, { useEffect } from 'react';
import {
    UserActivityLogInterface,
    PageConfigInterface,
    withMountDetectionCallbacksInterface
} from '../../interface/utils/hoc/WithPageMountDetectionInterface'

function withPageMountDetection<P>(Component: React.ComponentType<P>, config: PageConfigInterface, callbacks: withMountDetectionCallbacksInterface) {

    const { logUserActivity } = callbacks.logger()
    const userActivityLog: UserActivityLogInterface = {
        PageID: config.PageID,
        PageName: config.PageName,
        PageRoute: config.PageRoute,
        PageEnteredTime: "",
        PageLeftTime: "",
    }

    return function MountDetectionWrapper(props: P) {
        useEffect(() => {
            userActivityLog.PageEnteredTime = new Date().toISOString()
            return (() => {
                userActivityLog.PageLeftTime = new Date().toISOString()
                logUserActivity(userActivityLog)
            })
        }, []);

        return <Component {...props} config={config} />;
    }
}

export { withPageMountDetection };
