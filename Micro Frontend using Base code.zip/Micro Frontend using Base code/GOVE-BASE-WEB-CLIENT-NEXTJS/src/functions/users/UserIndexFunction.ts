/**
@CreatedBy        : Dinesh
@CreatedTime      : Dec 02 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contains config for main component
**/

import { UserIndexApi } from "../../api/users/UserIndexApi"

const userIndexApi = new UserIndexApi()

class UserIndexFunction {

    async ReadUserByFilter(filter: Object, fields: Object, limit: Number, page: Number, sort: Object) {
        return await userIndexApi.ReadUserByFilter(filter, fields, limit, page, sort)
    }

}


export { UserIndexFunction }
