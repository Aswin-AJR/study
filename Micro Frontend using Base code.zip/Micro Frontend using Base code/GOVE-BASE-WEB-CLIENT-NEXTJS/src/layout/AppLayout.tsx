import React, { useContext, useEffect, useState } from 'react'
import { Sidebar } from './Sidebar'
import { Topbar } from './Topbar';
import { Footer } from './Footer';
import styled, { useTheme } from 'styled-components'
import { AppLayoutConfig } from '../configs/layout/AppLayoutConfig';
import { UserSettingsContext } from '../pages/_app';
import _ from 'lodash'
import { AppLayoutInterface, UserSettingsInterface } from '../interface/layout/AppLayoutInterface'
import { TopbarConfig } from '../configs/layout/TopbarConfig';
import { SidebarConfig } from '../configs/layout/SidebarConfig';
import { FooterConfig } from '../configs/layout/FooterConfig';
import { AppConfig } from '../configs/pages/AppConfig';


/**
 * This interface defines properties of theme
 */

/**
 * Initializing the objects for imported classes
 */

let appConfig = new AppConfig()
let layoutConfig = new AppLayoutConfig()
let topbarConfig = new TopbarConfig()
let sidebarConfig = new SidebarConfig()
let footerConfig = new FooterConfig()

const LayoutContainer = styled.div`
    display: flex;
    height: 100vh;
`

const MainContainer = styled.div`
    display       : flex;
    flex-direction: column;
    height        : 100vh !important;
`

const MainDynamicComponent = styled.div`
    flex-grow: 1;
    background: $AppBackgroundColor;
    font-size: ${(props: any) => props?.fontsize + '!important' || '14px !important'};
`

function AppLayout(props: AppLayoutInterface) {

    const [appLayoutConfig, setAppLayoutConfig] = useState<any>(layoutConfig)
    const userSettings: UserSettingsInterface = useContext<any>(UserSettingsContext);
    const theme = useTheme()

    useEffect(() => {
        let appLayoutConfigClone: any = { ...appLayoutConfig }
        // appLayoutConfigClone.IS_SIDEBAR_VISIBLE = true
        setAppLayoutConfig(appLayoutConfigClone)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        // logMessage("User navigated to " + window.location.href + " on " + new Date())
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [window.location.href]);

    return (
        <>
            <LayoutContainer data-testid='base_web_layout_applayout_container'>
                {
                    appLayoutConfig?.APP_LAYOUT_CONFIG?.IS_SIDEBAR_VISIBLE &&
                    <Sidebar
                        configs={{
                            sideBarConfig: {
                                sidebarMenuConfig: sidebarConfig.GET_SIDEBAR_MENU_CONFIG(!_.isEmpty(userSettings) ? userSettings?.SidebarSettings : null),
                                sidebarAppLogoWidth: sidebarConfig.SIDEBAR_CONFIG.SIDEBAR_APP_LOGO_WIDTH,
                                sidebarAppLogoHeight: sidebarConfig.SIDEBAR_CONFIG.SIDEBAR_APP_LOGO_HEIGHT,
                            },
                            appConfig: {
                                appName: appConfig.APP_CONFIG.APP_NAME,
                                appLogo: appConfig.APP_CONFIG.APP_LOGO,
                                appTheme: theme
                            }
                        }}
                        data={{}}
                        callbacks={null}
                    />
                }
                <MainContainer data-testid="base_web_layout_applayout_maincontainer" className="main_container w-100">
                    {
                        appLayoutConfig?.APP_LAYOUT_CONFIG?.IS_TOPBAR_VISIBLE &&
                        <Topbar
                            configs={{
                                sideBarConfig: {
                                    isSidebarVisible: appLayoutConfig?.APP_LAYOUT_CONFIG?.IS_SIDEBAR_VISIBLE
                                },
                                appConfig: {
                                    appName: appConfig.APP_CONFIG.APP_NAME,
                                    appLogo: appConfig.APP_CONFIG.APP_LOGO,
                                    appTheme: theme
                                },
                                topbarConfig: {
                                    topbarMenuConfig: topbarConfig.GET_TOPBAR_MENU_CONFIG(),
                                    topbarAppLogoWidth: topbarConfig.TOPBAR_CONFIG.TOPBAR_APP_LOGO_WIDTH,
                                    topbarAppLogoHeight: topbarConfig.TOPBAR_CONFIG.TOPBAR_APP_LOGO_HEIGHT,
                                }
                            }}
                            data={{
                                tenantList: userSettings?.Tenant,
                                merchantInfo: userSettings?.Merchant,
                                instanceInfo: userSettings?.InstanceSettings,
                                userInfo: userSettings?.User
                            }}
                            callbacks={null}
                        />
                    }

                    {/** Dynamic component will be routed here */}
                    <MainDynamicComponent fontsize={theme?.FontSize} data-testid="base_web_layout_applayout_maindynamiccontainer" className="py-3 px-3 sm:px-6 lg:px-8 main_dynamic_component">
                        {props.children}
                    </MainDynamicComponent>

                    {appLayoutConfig?.APP_LAYOUT_CONFIG?.IS_FOOTER_VISIBLE
                        &&
                        <Footer
                            configs={{
                                footerConfig: {
                                    footerText: footerConfig.FOOTER_CONFIG.FOOTER_TEXT
                                },
                                appConfig: {
                                    appTheme: theme
                                },
                            }}
                            data={null}
                            callbacks={null}
                        />}
                </MainContainer>
            </LayoutContainer>
        </>
    )
}

export { AppLayout }