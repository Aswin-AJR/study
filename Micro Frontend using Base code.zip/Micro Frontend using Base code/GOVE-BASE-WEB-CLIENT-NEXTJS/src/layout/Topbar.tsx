/**
@CreatedBy        : Karthick DK
@CreatedTime      : Nov 17 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Dec 02 2022
@Description      : This file contains rendering logic for topbar component
**/

import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import { useRouter } from "next/router";
import { Avatar } from "primereact/avatar";
import { useProSidebar } from 'react-pro-sidebar';
import {
    RightOutlined
} from '@ant-design/icons';
import styled from 'styled-components'
import Image from "next/image";
import _ from 'lodash'
import { useAuth } from "../utils/context/UserAuthContextProvider";
import {
    TopbarMenusInterface,
    TenantListInterface,
    TopbarInterface,
} from '../interface/layout/TopbarInterface'

const RightOutlinedIcon = styled(RightOutlined)`
    color        : white;
    padding-left: 10px
`

const TopbarContainer = styled.div`
    flex-shrink: 0;
    font-size: ${(props: any) => props?.apptheme?.Fontsize + '!important' || '14px !important'};
`

const TopbarNavbar = styled(Navbar)`
    background-color: ${(props: any) => props?.apptheme?.TopbarBackgroundColor || '#1f1044'};
    height: 50px;
    margin: 4px;
    border-radius: 10px;
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    .app-name, .tenant-name{
        color:  ${(props: any) => props?.apptheme?.TopbarFontColor || '#1f1044'};
        font-size: ${(props: any) => props?.apptheme?.FontSize + '!important' || '14px !important'};
    }
`

const MenuItem = styled.div`
    display: flex;
    align-items: center;
    i, a {
        color: ${(props: any) => props?.apptheme?.TopbarFontColor + '!important' || 'black + !important'};
        font-size:${(props: any) => props?.apptheme?.FontSize + '!important'} 
    }
`

const ProfileDropdown = styled(NavDropdown)`
    .dropdown-menu[data-bs-popper]{
        left: unset;
        right: 1px;
    }
`



function Topbar(props: TopbarInterface) {
    const { collapseSidebar, toggleSidebar } = useProSidebar();
    const router = useRouter()
    const { setIsUserAuthenticated } = useAuth();

    return (
        <TopbarContainer apptheme={props?.configs?.appConfig?.appTheme} data-testid="base_web_layout_topbar" className="topbar_container">
            <TopbarNavbar
                collapseOnSelect
                expand="lg"
                className="topbar_navigator"
                sticky="top"
                apptheme={props?.configs?.appConfig?.appTheme}
                data-testid="base_web_layout_topbar_navbar"
            >
                {props?.configs?.sideBarConfig?.isSidebarVisible &&
                    <Navbar.Brand className="d-sm-block d-lg-none pt-0" data-testid="base_web_layout_topbar_sidebartoggler">
                        <RightOutlinedIcon onClick={() => { collapseSidebar(); toggleSidebar(true) }} />
                    </Navbar.Brand>
                }
                <Navbar.Brand className="app_logo ms-2 me-0">
                    <Image
                        src={props?.configs?.appConfig?.appLogo}
                        width={props?.configs?.topbarConfig?.topbarAppLogoWidth}
                        height={props?.configs?.topbarConfig?.topbarAppLogoHeight}
                        className="d-inline-block align-top"
                        alt="app=logo"
                        data-testid="base_web_layout_topbar_applogo"
                    />
                </Navbar.Brand>
                <Navbar.Brand data-testid="base_web_layout_topbar_appname" className="ms-3 app-name">
                    <Nav.Link
                        onClick={() => router.push("/")}
                        aria-controls="popup_menu"
                        aria-haspopup >
                        {props?.configs?.appConfig?.appName}
                    </Nav.Link>
                </Navbar.Brand>
                <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                <Navbar.Collapse id="responsive-navbar-nav" className="px-3 sm:px-3">
                    <Nav className="me-auto">
                        {
                            props?.configs?.topbarConfig?.topbarMenuConfig?.map((menu: TopbarMenusInterface) =>
                                <MenuItem className='me-2' apptheme={props?.configs?.appConfig?.appTheme} key={menu?.menuKey}>
                                    {!menu.subMenus ?
                                        menu.isMenuVisible &&
                                        <>
                                            {menu?.menuIcon}
                                            <Nav.Link
                                                onClick={() => router.push(menu?.menuPath)}
                                                aria-controls="popup_menu"
                                                aria-haspopup >
                                                {menu?.menuDisplayName}
                                            </Nav.Link>
                                        </> :
                                        menu.isMenuVisible &&
                                        <ProfileDropdown disabled={!menu?.isMenuEnabled} key={menu?.menuKey} title={menu?.menuDisplayName} id={menu?.menuName}>
                                            {
                                                menu?.subMenus?.map((subMenu: TopbarMenusInterface) =>
                                                    subMenu?.isMenuVisible &&
                                                    <div key={subMenu?.menuKey}>
                                                        <NavDropdown.Item disabled={!subMenu?.isMenuEnabled} key={subMenu?.menuKey} onClick={() => router.push(subMenu?.menuPath)}>
                                                            {subMenu?.menuDisplayName}
                                                        </NavDropdown.Item>
                                                        {subMenu.isDividerVisibleAtBottom && <NavDropdown.Divider />}
                                                    </div>
                                                )
                                            }
                                        </ProfileDropdown>
                                    }
                                </MenuItem>
                            )
                        }
                    </Nav>
                    {!_.isEmpty(props?.data?.instanceInfo?.EnvironmentName) && <span data-testid="base_web_layout_topbar_env_name" className="badge rounded-pill text-bg-info">{props?.data?.instanceInfo?.EnvironmentName}</span>}
                    <Nav>
                        <Nav.Link className="tenant-name" data-testid="base_web_layout_topbar_tenant_name">{!_.isEmpty(props.data.tenantList) && props.data.tenantList[0].TenantName}</Nav.Link>
                        <ProfileDropdown className='user-profile' title={
                            <Avatar
                                label={!_.isEmpty(props.data.userInfo) ? props.data.userInfo.UserName.substring(0, 1) : "-"}
                                className="mr-2"
                                style={{ backgroundColor: "#2196F3", color: "#ffffff" }}
                                shape="circle"
                            />
                        } id="navbarScrollingDropdown">
                            <NavDropdown.Item data-testid="base_web_layout_topbar_user_name">{!_.isEmpty(props.data.userInfo) && props.data.userInfo.UserName}</NavDropdown.Item>
                            <NavDropdown.Divider />
                            {!_.isEmpty(props.data.tenantList) && props.data.tenantList.map((tenant: TenantListInterface, index: number) =>
                                <NavDropdown.Item data-testid="base_web_layout_topbar_tenant_list" key={index}>{tenant.TenantName}</NavDropdown.Item>
                            )}
                            {!_.isEmpty(props.data.tenantList) && <NavDropdown.Divider />}
                            <NavDropdown.Item data-testid="base_web_layout_topbar_user_signout" onClick={() => setIsUserAuthenticated(false)}>Sign Out</NavDropdown.Item>
                        </ProfileDropdown>
                    </Nav>
                </Navbar.Collapse>
            </TopbarNavbar>
        </TopbarContainer >
    );
}

export { Topbar };
