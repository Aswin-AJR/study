/**
@CreatedBy        : Karthick DK
@CreatedTime      : Nov 17 2022
@ModifiedBy       : Dinesh
@ModifiedTime     : Nov 30 2022
@Description      : This file contains rendering logic for footer component
**/

import React from "react";
import styled from 'styled-components'
import { FooterInterface } from '../interface/layout/FooterInterface'

/**
 * This interface defines properties of footer
 */


const FooterContainer = styled.div`
    flex-shrink: 0;
    font-size: ${(props: any) => props?.apptheme?.FontSize + '!important' || '14px !important'};;
    text-align: center;
    padding-top: 6px;
    padding-bottom: 6px;
    background-color: whitesmoke;
`

/**
 * This is a functional component of footer
 */
function Footer(props: FooterInterface) {
    return (
        <FooterContainer apptheme={props?.children?.configs?.appConfig?.appTheme} data-testid="footer_component" className="footer_container" >
            {props?.children?.configs?.footerConfig?.footerText}
        </FooterContainer>
    );
}

export { Footer };
