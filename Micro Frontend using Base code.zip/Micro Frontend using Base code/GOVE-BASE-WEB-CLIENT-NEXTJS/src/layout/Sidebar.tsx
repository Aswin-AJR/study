import { Sidebar as SideBar, SubMenu, Menu, MenuItem, useProSidebar } from 'react-pro-sidebar';
import {
    RightOutlined,
    LeftOutlined
} from '@ant-design/icons';
import styled from 'styled-components'
import { useState } from 'react';
import Image from 'next/image';
import { SidebarMenusInterface, SidebarInterface } from '../interface/layout/SidebarInterface'
import { useRouter } from 'next/router';


const Menus = styled(Menu)`
    height        : 100% !important;
`
const ProSidebar = styled(SideBar)`
    z-index: 1050 !important;
    margin-left: 5px;
    margin-right: 5px;
    margin-top: 5px;
    margin-bottom: 5px;
    min-width: 60px !important;
    font-size: ${(props: any) => props?.children?.apptheme?.FontSize + '!important' || '14px !important'};
    .ps-sidebar-container {
        border-radius: 12px;
        color: ${(props: any) => props?.children?.apptheme?.SidebarFontColor || 'white'};
        background-color: ${(props: any) => props?.children?.apptheme?.SidebarBackgroundColor || 'whitesmoke'};
        box-shadow: 0 0 15px 0 #b7b3c0;
    }
    .ps-submenu-content > ul {
        background: ${(props: any) => props?.children?.apptheme?.SidebarBackgroundColor || 'whitesmoke'}
    }
    .sidebar-menu.active a{
        background: ${(props: any) => props?.children?.apptheme?.AppPrimaryColor || 'white'};
        color: ${(props: any) => props?.children?.apptheme?.TopbarFontColor || 'black'};
        border-radius: 15px;
        margin: 4px;
    }
    .material-icons{
        font-size: 19px
    }
    a {
        padding-left: 15px;
        padding-right: 15px;
    }
`

const CollapsibleMenuItem = styled(MenuItem)`
    position: absolute !important;
    bottom : 0px !important;
    display: inherit !important;
    text-align: center !important;
`

function Sidebar(props: SidebarInterface) {
    console.log('%c⧭', 'color: #aa00ff', props?.children, props?.children?.configs?.sideBarConfig?.sidebarMenuConfig);
    const router = useRouter()
    const { collapseSidebar } = useProSidebar();
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false)

    const handleSidebarCollapse = () => {
        setIsSidebarCollapsed(!isSidebarCollapsed)
        collapseSidebar()
    }

    const handleMenuHighlight = (path: string) => {
        var urlPath = new URL(window.location.href).pathname;
        if (urlPath === path) {
            return true
        } else {
            return false
        }
    }

    const getMenus = (menu: SidebarMenusInterface) => {
        if (menu.isMenuEnabled) {
            return (
                <MenuItem
                    onClick={() => router.push(menu.menuPath)}
                    className={`sidebar-menu ${handleMenuHighlight(menu.menuPath) && 'active'}`}
                    data-testid='base_web_layout_sidebar_sidebarmenu'
                    key={menu.menuKey}
                    icon={menu.menuIcon}
                >
                    {menu.menuDisplayName}
                </MenuItem>
            )
        }
    }

    const getSubMenus = (menu: SidebarMenusInterface) => {
        console.log('%c⧭', 'color: #e50000', menu);
        if (menu.isMenuEnabled) {
            return (
                <SubMenu
                    data-testid='base_web_layout_sidebar_sidebarmenus'
                    key={menu.menuKey}
                    icon={menu.menuIcon}
                    label={menu.menuDisplayName}
                >
                    {
                        menu?.subMenus?.map((submenuObj: SidebarMenusInterface) =>
                            submenuObj.subMenus ? getSubMenus(submenuObj) : getMenus(submenuObj)
                        )
                    }
                </SubMenu>
            )
        }
    }

    return (
        <ProSidebar
            defaultCollapsed
            breakPoint='md'
            apptheme={props?.children?.configs?.appConfig?.appTheme}
            data-testid='base_web_layout_sidebar_container'
        >
            <Menus className='h-100'>
                <div className='text-center py-2'>
                    <MenuItem icon={
                        <Image
                            src={props?.children.configs.appConfig?.appLogo}
                            width={props?.children?.configs?.sideBarConfig?.sidebarAppLogoWidth}
                            height={props?.children?.configs?.sideBarConfig?.sidebarAppLogoHeight}
                            alt='app-logo'
                            data-testid='base_web_layout_sidebar_applogo'
                        />
                    }>
                        <b data-testid='base_web_layout_sidebar_appname'>{props?.children?.configs?.appConfig?.appName}</b>
                    </MenuItem>
                </div>
                {
                    props?.children?.configs?.sideBarConfig?.sidebarMenuConfig?.length !== 0 &&
                    props?.children?.configs?.sideBarConfig?.sidebarMenuConfig?.map((menu: SidebarMenusInterface) =>
                        menu.subMenus ? getSubMenus(menu) : getMenus(menu)
                    )
                }
                <CollapsibleMenuItem onClick={() => handleSidebarCollapse()}>
                    {!isSidebarCollapsed ?
                        <RightOutlined data-testid='base_web_layout_sidebar_expandsidebar' /> :
                        <LeftOutlined data-testid='base_web_layout_sidebar_collapsesidebar' />
                    }
                </CollapsibleMenuItem>
            </Menus>
        </ProSidebar>
    );
}

export { Sidebar }