/** @type {import('next').NextConfig} */

/**
 * Remote applist add
 */
const NextFederationPlugin = require("@module-federation/nextjs-mf");
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  webpack: (config, options) => {
    config.plugins.push(
      new NextFederationPlugin({
        name: "Project2", /** */
        filename: "static/chunks/remoteEntry.js",
        exposes: {
          './PAGES': "./src/exposes/expose.tsx"
        },
        remotes: {},
        shared: {},
        extraOptions: {
          automaticAsyncBoundary: true,
        },
      })
    );
    return config;
  },
};
module.exports = nextConfig;
