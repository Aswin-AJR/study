import { useEffect, useState } from "react"


export default function Home() {
  const [render, SetRender] = useState<any>(null)
  useEffect(() => {
    const getRemotePage = async () => {
      const AppList: any = {
        App1: (await import("App1/PAGES" as any) as any).default
      }
      AppList && SetRender(AppList)
    }
    getRemotePage()
  }, [])


  const handleRenderDashBoard = (component: any) => {
    let Remote: any = null;
    if (render?.App1 && render?.App1?.Home) {
      Remote = render?.App1?.Home;
      return (
        <Remote key={"App1" + "_" + "Home"} >
          {component}
        </Remote>
      )
    } else {
      return null
    }
  }
  return (
    <>{render &&handleRenderDashBoard("HI")}</>
  )
}
