/** @type {import('next').NextConfig} */

/**
 * Remote applist add
 */
const NextFederationPlugin = require("@module-federation/nextjs-mf");

const remote = (isServer) => {
  /**
   * Developer
   */
  const location = isServer && false ? "ssr" : "chunks";
  return {
    App1: `Project2@http://localhost:3000/_next/static/${location}/remoteEntry.js`,
  };
};
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  webpack: (config, options) => {
    config.plugins.push(
      new NextFederationPlugin({
        name: "project1",
        filename: "static/chunks/remoteEntry.js",
        exposes: {
        },
        remotes: remote(options.isServer),
        shared: {},
        extraOptions: {
          automaticAsyncBoundary: true,
        },
      })
    );
    return config;
  },
};
module.exports = nextConfig;
